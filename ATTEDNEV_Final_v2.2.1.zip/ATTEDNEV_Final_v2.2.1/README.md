# A.T.T.E.D.N.E.V. — v2.2.0

**Angular Trajectory Tracking & Energy Dynamics Numerical Experiment Visualizer**

A browser-based engineering workspace for a nonlinear planar pendulum. A.T.T.E.D.N.E.V. includes an interactive Three.js 3D scene, a two-dimensional no-WebGL fallback, fixed-step numerical integration, optional sinusoidal virtual excitation, simulation-only event triggers, response charts, a frequency-response sweep, convergence analysis, diagnostics, AutoCAD-oriented geometry handoff, and CSV/JSON experiment exports.

## Scope and safety

This is an educational software simulation of idealized pendulum dynamics. It contains no person, injury scenario, real-world trap mechanism, actuator output, control wiring, restraint, blade, or fabrication instruction. A trigger is a local software condition that appends an event to the page's log. The visual support frame is illustrative and is not a structural or fabrication drawing. The drive term is a mathematical excitation input only; it is not connected to hardware.

## Start locally

Requirements: Node.js 18+ for the test runner, and a modern browser. Internet access is needed to load Three.js and its OrbitControls module from jsDelivr (and the optional Google Fonts stylesheet).

```bash
npm test
npm run serve
```

Open `http://localhost:3000`. Do not open `index.html` using a `file://` URL; ES modules should be served over HTTP.

## Main controls

- **Run / Pause** starts or stops the fixed-step solver. Space toggles run/pause when focus is not inside an input or select.
- **Reset** restarts the current configuration and clears sampled history and events.
- **Step 1 frame** advances one numerical integration interval.
- Orbit with pointer drag and zoom with the wheel in the 3D view. Camera home, grid visibility, and velocity vector visibility are available in the viewport toolbar.
- Length, bob mass, gravity, damping, initial angle, virtual drive amplitude, and virtual drive frequency are adjustable while paused. Changing a physical parameter starts a clean run so samples are not mixed across model configurations.
- Choose the preset **Driven response / resonance** to load a small-angle, sinusoidally excited experiment.
- Select the solver method and integration frequency independently. Available methods are RK4, semi-implicit Euler, explicit Euler, and a split damped velocity-Verlet method. Rates range from 30 Hz to 480 Hz.
- Trigger rows can be armed/disarmed and threshold-based conditions can be edited. Crossing and turning-point triggers detect sign transitions.
- Select the plotted response channel and export recorded samples as CSV or a structured JSON experiment bundle.
- Use the **CAD handoff / AutoCAD** panel to export the visible frame, pivot, rod, bob, and swing-envelope geometry as a layer-tagged CSV. Enter a custom list of static angles to export multiple CAD-ready pendulum positions in one file. Coordinates use metres in the same world X–Y swing plane as the 3D view.
- Generate an editable AutoLISP script from the same panel. The script defines `ATTEDNEVBUILD`, `ATTEDNEVPOSITIONS`, `ATTEDNEVDIMS`, `ATTEDNEVLAYERSETUP`, and `ATTEDNEVHELP`, color-codes named AutoCAD layers, adds frame/pivot/length/angle/mass annotations, and can be downloaded as a `.lsp` file or copied into Notepad for `APPLOAD`.

## Mathematical model

The angle is measured from the downward vertical. The bob is modeled as a point mass at distance `L` from a fixed pivot; the rod is rigid and massless. With optional sinusoidal virtual excitation, the equation is

```text
theta_ddot + c * theta_dot + (g / L) * sin(theta)
  = A * sin(2*pi*f*t + phi)
```

where `theta` is in radians, `c` in s^-1, `g` in m/s^2, `L` in metres, `A` in rad/s^2, `f` in Hz, and `phi` in radians internally (the UI parameter is stored in degrees). `A = 0` disables external excitation. The drive is part of the mathematical model only.

The ideal point-mass energies are

```text
K = 0.5 * m * (L * omega)^2
V = m * g * L * (1 - cos(theta))
E = K + V
```

Energy is not expected to remain constant when damping or external excitation is active. The diagnostics therefore display signed energy change relative to the first recorded sample, not merely a presumed energy loss. The percent change is undefined when initial energy is effectively zero.

The undamped small-angle reference frequency and period are `sqrt(g/L)` and `2*pi*sqrt(L/g)`. At larger amplitudes, the nonlinear oscillation period is longer than the small-angle approximation.

## Studies

### Frequency response

The frequency sweep runs a separate simulated experiment for each forcing frequency. It starts the bob at zero angle, applies the selected virtual drive amplitude, integrates for 16 seconds at 180 Hz, and estimates the steady-window response amplitude as half the peak-to-peak angle over the last 4 seconds. The plotted maximum is the peak among sampled frequencies, not an exact continuous-frequency resonance solution. Change length, damping, drive amplitude, and frequency bounds in code to explore other cases.

### Numerical convergence

The convergence study runs the selected integrator at 30, 60, 120, 240, and 480 Hz for a common final simulated time. Final angle and angular rate are compared with the 480 Hz result. This is a numerical reference comparison, not comparison against an exact solution. It is most informative when RK4 is selected and when the reference itself is sufficiently resolved.

## Software architecture

- `index.html`: application layout and semantic controls.
- `styles.css`: responsive theme and study layouts.
- `src/main.js`: renderer initialization and fallback selection.
- `src/app.js`: UI wiring, fixed-step clock, event processing, and export orchestration.
- `src/config.js`: app constants, defaults, presets, and trigger definitions.
- `src/physics/pendulum.js`: nonlinear equation and four integration methods.
- `src/physics/energy.js`: energy, angular momentum, and state summary.
- `src/physics/sensors.js`: ideal virtual sensor channels.
- `src/physics/triggers.js`: threshold, zero-crossing, and turning-point event monitor.
- `src/physics/history.js`: bounded history buffer and sample decimation.
- `src/physics/analysis.js`: frequency, damping, period, RMS, and energy diagnostics.
- `src/physics/convergence.js`: fixed-duration step-size comparison.
- `src/physics/sweeps.js`: sinusoidal excitation frequency-response sweep.
- `src/visual/scene.js`: Three.js scene, camera, generic frame, pendulum, trail, and velocity vector.
- `src/visual/modelDimensions.js`: shared frame, pivot, rod, and bob dimensions for rendering and CAD export.
- `src/visual/fallback.js`: accessible 2D schematic when WebGL is unavailable.
- `src/ui/`: parameter controls, dashboard, response chart, and study renderers.
- `src/utils/cad.js`: AutoCAD layer-tagged geometry and static-position CSV generation.
- `src/utils/autolisp.js`: parameterized AutoLISP command-file generation for AutoCAD.
- `src/utils/`: formatting and browser download helpers.
- `tests/physics.test.js`, `tests/cad.test.js`, and `tests/autolisp.test.js`: 17 automated physics, CAD, and AutoLISP regression tests.
- `docs/`: detailed model, numerical-method, event, data, validation, and browser-support notes.

## Manus deployment

Upload the entire ZIP archive to a Manus website task and paste the instructions from `MANUS_PUBLISH_PROMPT.txt`. Ask Manus to preserve the local `src/` modules and `styles.css`, test the requested interactions, then publish with public visibility. The archive does not itself publish to an account or reserve a permanent URL; Manus generates the public site address when publishing succeeds.

## Validation

The bundled Node suite currently passes 17/17 tests. These cover the small-angle period formula, input validation, undamped RK4 energy conservation, integrator stepping, damped energy decay, sinusoidal drive response, trigger threshold and crossing detection, diagnostics, convergence behavior, sweep output, CAD angle normalization, world-coordinate pose generation, layer-tagged geometry rows, AutoLISP command generation, and safe command-file content. This does not replace browser-based cross-device QA, experimental validation, formal verification, or engineering certification.

## Build verification note

The v2.2.0 package was validated with `node --check` across the JavaScript source and tests, `npm test` (17/17 passing), and a static asset check for the CAD and AutoLISP stylesheets and export modules. The headless browser smoke-test process did not complete in the build environment, so no claim is made that the interactive page was browser-rendered end-to-end here. Use the browser checklist in `docs/17-validation-matrix.md` before treating the hosted site as fully QA-approved.
