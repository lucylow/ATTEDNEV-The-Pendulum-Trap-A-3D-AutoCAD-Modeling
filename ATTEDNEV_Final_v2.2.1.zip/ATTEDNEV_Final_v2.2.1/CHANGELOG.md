# Changelog

## 2.0.0 — Driven response and analysis upgrade

- Added a sinusoidal virtual excitation term to the nonlinear equation of motion.
- Added amplitude and frequency controls and a driven-response preset.
- Reworked velocity Verlet as a split damped update with exact half-step linear damping.
- Added software-only center-crossing and turning-point event triggers.
- Added selectable integration rates from 30 Hz through 480 Hz.
- Added a frequency-response sweep and a numerical step-size convergence study.
- Added signed energy-change diagnostics to avoid describing externally driven energy gain as energy loss.
- Added virtual drive-acceleration sensor channels to exports.
- Added a 2D canvas schematic fallback if WebGL initialization fails.
- Expanded regression coverage from 6 to 12 tests and rewrote the engineering documentation.

## 1.0.0 — Initial browser prototype

- Added Three.js visualization, ideal nonlinear pendulum solver, virtual threshold triggers, plots, diagnostics, and data exports.
