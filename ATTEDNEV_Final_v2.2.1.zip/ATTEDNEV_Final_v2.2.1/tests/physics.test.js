import test from 'node:test';
import assert from 'node:assert/strict';
import { PendulumSolver, estimateSmallAnglePeriod } from '../src/physics/pendulum.js';
import { calculateEnergy } from '../src/physics/energy.js';
import { TriggerEngine } from '../src/physics/triggers.js';
import { calculateDiagnostics } from '../src/physics/analysis.js';
import { runConvergenceStudy } from '../src/physics/convergence.js';
import { runFrequencySweep } from '../src/physics/sweeps.js';

const parameters = { length: 2.4, mass: 8, gravity: 9.81, damping: 0, initialAngleDeg: 10, integrator: 'rk4', driveAmplitude: 0, driveFrequencyHz: 0.65, drivePhaseDeg: 0 };

test('small-angle period follows the analytical expression', () => {
  const expected = 2 * Math.PI * Math.sqrt(parameters.length / parameters.gravity);
  assert.ok(Math.abs(estimateSmallAnglePeriod(parameters.length, parameters.gravity) - expected) < 1e-12);
});

test('period function rejects non-positive inputs', () => {
  assert.throws(() => estimateSmallAnglePeriod(0, 9.81), RangeError);
  assert.throws(() => estimateSmallAnglePeriod(1, -1), RangeError);
});

test('RK4 conserves mechanical energy closely for the undamped ideal model', () => {
  const solver = new PendulumSolver(parameters);
  const start = calculateEnergy(solver.snapshot(), parameters).total;
  for (let i = 0; i < 120 * 12; i += 1) solver.step(1 / 120);
  const end = calculateEnergy(solver.snapshot(), parameters).total;
  assert.ok(Math.abs(end - start) / start < 1e-6, `relative energy drift was ${Math.abs(end - start) / start}`);
});

test('semi-implicit, explicit Euler and split Verlet all advance finite state', () => {
  for (const integrator of ['semi-implicit', 'euler', 'verlet']) {
    const solver = new PendulumSolver({ ...parameters, integrator });
    solver.step(1 / 120);
    assert.ok(solver.time > 0);
    assert.ok(Number.isFinite(solver.state.omega));
    assert.ok(Number.isFinite(solver.state.theta));
  }
});

test('positive damping reduces mechanical energy over time', () => {
  const damped = { ...parameters, damping: 0.1 };
  const solver = new PendulumSolver(damped);
  const start = calculateEnergy(solver.snapshot(), damped).total;
  for (let i = 0; i < 120 * 10; i += 1) solver.step(1 / 120);
  const end = calculateEnergy(solver.snapshot(), damped).total;
  assert.ok(end < start);
});

test('sinusoidal virtual drive changes the angular response', () => {
  const free = new PendulumSolver({ ...parameters, initialAngleDeg: 0 });
  const driven = new PendulumSolver({ ...parameters, initialAngleDeg: 0, damping: 0.05, driveAmplitude: 0.8 });
  for (let i = 0; i < 120 * 4; i += 1) { free.step(1 / 120); driven.step(1 / 120); }
  assert.ok(Math.abs(driven.state.theta) > 0.01);
  assert.ok(Math.abs(driven.state.theta - free.state.theta) > 0.01);
});

test('solver rejects invalid physical parameters and integration steps', () => {
  assert.throws(() => new PendulumSolver({ ...parameters, length: 0 }), RangeError);
  assert.throws(() => new PendulumSolver({ ...parameters, initialAngleDeg: Number.NaN }), RangeError);
  assert.throws(() => new PendulumSolver({ ...parameters, sampleInterval: 0 }), RangeError);
  const solver = new PendulumSolver(parameters);
  assert.throws(() => solver.step(0), RangeError);
  assert.throws(() => solver.step(Number.NaN), RangeError);
  assert.throws(() => solver.setIntegrator('unknown'), RangeError);
});

test('threshold trigger fires once and resets cleanly', () => {
  const engine = new TriggerEngine([{ id: 'test', name: 'test event', enabled: true, kind: 'angle', threshold: 20, direction: 'above', repeat: false }]);
  const sample = { time: 0.4, theta: 0.36, angleDeg: 21, omega: 0, total: 0 };
  assert.equal(engine.evaluate(sample).length, 1);
  assert.equal(engine.evaluate({ ...sample, time: 0.5 }).length, 0);
  engine.reset();
  assert.equal(engine.evaluate(sample).length, 1);
});

test('zero-crossing and turning-point triggers detect state transitions', () => {
  const engine = new TriggerEngine([
    { id: 'cross', name: 'center', enabled: true, kind: 'zero-crossing', repeat: true },
    { id: 'turn', name: 'turn', enabled: true, kind: 'turning-point', repeat: true },
  ]);
  engine.evaluate({ time: 0, theta: 0.2, angleDeg: 11.46, omega: -0.5, total: 1 });
  const events = engine.evaluate({ time: 0.1, theta: -0.1, angleDeg: -5.73, omega: 0.2, total: 1 });
  assert.deepEqual(events.map((item) => item.id).sort(), ['cross', 'turn']);
});

test('diagnostics return finite frequency, theoretical period and signed energy change', () => {
  const solver = new PendulumSolver(parameters);
  const samples = [];
  for (let i = 0; i < 120 * 3; i += 1) {
    solver.step(1 / 120);
    const state = solver.snapshot();
    samples.push({ ...state, angleDeg: state.angleDeg, total: calculateEnergy(state, parameters).total });
  }
  const report = calculateDiagnostics(samples, parameters);
  assert.ok(Number.isFinite(report.naturalFrequency));
  assert.ok(Number.isFinite(report.theoreticalPeriod));
  assert.ok(Number.isFinite(report.energyChangePercent));
  assert.ok(report.sampleCount > 0);
});

test('RK4 convergence error decreases as the integration step is refined', () => {
  const rows = runConvergenceStudy({ ...parameters, initialAngleDeg: 37 }, { duration: 8 });
  assert.equal(rows.length, 5);
  assert.ok(rows[1].angleErrorDeg > rows[2].angleErrorDeg);
  assert.ok(rows[2].angleErrorDeg > rows[3].angleErrorDeg);
  assert.equal(rows.at(-1).reference, true);
});

test('frequency sweep returns a finite response curve and rejects zero drive', () => {
  const report = runFrequencySweep({ ...parameters, driveAmplitude: 0.8 }, { points: 8, duration: 5, windowSeconds: 2, dt: 1 / 120 });
  assert.equal(report.results.length, 8);
  assert.ok(report.results.every((row) => Number.isFinite(row.amplitudeDeg)));
  assert.ok(Number.isFinite(report.peak.frequencyHz));
  assert.throws(() => runFrequencySweep(parameters), RangeError);
});
