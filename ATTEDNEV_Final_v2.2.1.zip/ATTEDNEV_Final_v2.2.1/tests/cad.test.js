import test from 'node:test';
import assert from 'node:assert/strict';
import { buildCadRows, normalizeAngles, pendulumPose } from '../src/utils/cad.js';

test('normalizes CAD angle lists and removes invalid duplicates', () => {
  assert.deepEqual(normalizeAngles('-45, 0, 45, 45, 90, nope'), [-45, 0, 45]);
});

test('computes pendulum coordinates in the simulator swing plane', () => {
  const pose = pendulumPose(2.4, 30, 5.19);
  assert.ok(Math.abs(pose.x - 1.2) < 1e-6);
  assert.ok(Math.abs(pose.y - (5.19 - 2.4 * Math.cos(Math.PI / 6))) < 1e-6);
  assert.equal(pose.z, 0);
});

test('builds frame, pivot, pendulum positions, and swing-envelope rows', () => {
  const rows = buildCadRows({ length: 2.4, mass: 8, initialAngleDeg: 35 }, [-30, 0, 30]);
  assert.equal(rows[0].entity_type, 'BOX');
  assert.equal(rows[4].component, 'pivot');
  assert.equal(rows.filter((item) => item.layer === 'PENDULUM').length, 6);
  assert.equal(rows.filter((item) => item.layer === 'SWING_ENVELOPE').length, 17);
  assert.equal(rows.find((item) => item.component === 'rod_position_1').angle_deg, -30);
});
