import test from 'node:test';
import assert from 'node:assert/strict';
import { autoLispFilename, generateAutoLisp } from '../src/utils/autolisp.js';

test('generates safe AutoLISP commands, layers, and current parameters', () => {
  const script = generateAutoLisp({ length: 2.4, mass: 8, initialAngleDeg: 35 }, [-30, 0, 30]);
  assert.match(script, /defun c:ATTEDNEVBUILD/);
  assert.match(script, /ATTEDNEV_FRAME/);
  assert.match(script, /ATTEDNEV_ENVELOPE/);
  assert.match(script, /ATTEDNEVDIMS/);
  assert.match(script, /ATTEDNEVLAYERSETUP/);
  assert.match(script, /FRAME WIDTH = 3\.6 m/);
  assert.match(script, /\(att:set-layer "ATTEDNEV_PENDULUM" "30"\)/);
  assert.match(script, /2\.4/);
  assert.match(script, /POSITION_3/);
  assert.doesNotMatch(script, /command-s.*ERASE|command-s.*PURGE/i);
});

test('creates a deterministic AutoLISP filename', () => {
  assert.equal(autoLispFilename({ initialAngleDeg: -35 }), 'attednev_pendulum_-35deg.lsp');
});
