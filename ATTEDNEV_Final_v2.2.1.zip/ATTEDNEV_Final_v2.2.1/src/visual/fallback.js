/** Accessible 2D schematic fallback when WebGL is unavailable. */
export class CanvasPendulumScene {
  constructor(container) {
    this.container = container;
    this.canvas = document.createElement('canvas');
    this.canvas.setAttribute('aria-label', 'Two-dimensional pendulum schematic');
    this.canvas.style.width = '100%';
    this.canvas.style.height = '100%';
    this.canvas.tabIndex = 0;
    container.replaceChildren(this.canvas);
    this.context = this.canvas.getContext('2d');
    this.state = { theta: 0, time: 0 };
    this.length = 2.4;
    this.gridVisible = true;
    this.vectorsVisible = false;
    this.resizeObserver = new ResizeObserver(() => this.render());
    this.resizeObserver.observe(container);
    this.render();
  }

  update(state, length) { this.state = state; this.length = length; }
  render() {
    const rect = this.container.getBoundingClientRect();
    if (!rect.width || !rect.height || !this.context) return;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    this.canvas.width = Math.round(rect.width * dpr);
    this.canvas.height = Math.round(rect.height * dpr);
    const ctx = this.context;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    const w = rect.width, h = rect.height;
    ctx.clearRect(0, 0, w, h);
    const gradient = ctx.createRadialGradient(w * .5, h * .5, 10, w * .5, h * .5, h * .8);
    gradient.addColorStop(0, '#172c43'); gradient.addColorStop(1, '#0b1422');
    ctx.fillStyle = gradient; ctx.fillRect(0, 0, w, h);
    if (this.gridVisible) {
      ctx.strokeStyle = 'rgba(100,145,190,.13)'; ctx.lineWidth = 1;
      for (let y = h * .7; y < h; y += 24) { ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(w, y); ctx.stroke(); }
    }
    const scale = Math.min(h * .42 / Math.max(this.length, 1), w * .3 / Math.max(this.length, 1));
    const pivot = { x: w / 2, y: h * .18 };
    const bob = { x: pivot.x + Math.sin(this.state.theta) * this.length * scale, y: pivot.y + Math.cos(this.state.theta) * this.length * scale };
    ctx.strokeStyle = '#77b6ef'; ctx.lineWidth = 5; ctx.lineCap = 'round';
    ctx.beginPath(); ctx.moveTo(pivot.x - 80, pivot.y - 12); ctx.lineTo(pivot.x + 80, pivot.y - 12); ctx.stroke();
    ctx.strokeStyle = '#d4e1ef'; ctx.lineWidth = 3;
    ctx.beginPath(); ctx.moveTo(pivot.x, pivot.y); ctx.lineTo(bob.x, bob.y); ctx.stroke();
    ctx.fillStyle = '#9ebbd8'; ctx.beginPath(); ctx.arc(pivot.x, pivot.y, 7, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = '#ffa267'; ctx.beginPath(); ctx.arc(bob.x, bob.y, 19, 0, Math.PI * 2); ctx.fill();
    ctx.strokeStyle = '#8e482a'; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(bob.x, bob.y, 19, 0, Math.PI * 2); ctx.stroke();
    if (this.vectorsVisible && Math.abs(this.state.omega || 0) > .01) {
      const direction = Math.sign(this.state.omega);
      const vx = direction * Math.cos(this.state.theta), vy = -direction * Math.sin(this.state.theta);
      const mag = 30 + Math.min(55, Math.abs(this.state.omega) * 12);
      ctx.strokeStyle = '#5dd7a0'; ctx.lineWidth = 3;
      ctx.beginPath(); ctx.moveTo(bob.x, bob.y); ctx.lineTo(bob.x + vx * mag, bob.y + vy * mag); ctx.stroke();
    }
    ctx.fillStyle = '#92a9c2'; ctx.font = '10px monospace';
    ctx.fillText('WEBGL UNAVAILABLE · 2D SCHEMATIC FALLBACK', 14, h - 17);
  }
  homeCamera() { this.render(); }
  toggleGrid() { this.gridVisible = !this.gridVisible; this.render(); }
  toggleVectors() { this.vectorsVisible = !this.vectorsVisible; this.render(); }
  clearTrail() {}
  dispose() { this.resizeObserver?.disconnect(); this.container.replaceChildren(); }
}
