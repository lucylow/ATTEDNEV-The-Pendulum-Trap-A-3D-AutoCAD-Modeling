import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { CAD_MODEL, CAD_PIVOT_HEIGHT } from './modelDimensions.js';

const MATERIALS = {
  frame: new THREE.MeshStandardMaterial({ color: 0x4b83bd, metalness: 0.72, roughness: 0.34 }),
  beam: new THREE.MeshStandardMaterial({ color: 0x76b3ee, metalness: 0.62, roughness: 0.3 }),
  joint: new THREE.MeshStandardMaterial({ color: 0x9cb8d6, metalness: 0.85, roughness: 0.22 }),
  rod: new THREE.MeshStandardMaterial({ color: 0xa9c0d8, metalness: 0.75, roughness: 0.3 }),
  bob: new THREE.MeshStandardMaterial({ color: 0xffa267, metalness: 0.48, roughness: 0.24 }),
  bobDark: new THREE.MeshStandardMaterial({ color: 0x8e482a, metalness: 0.62, roughness: 0.28 }),
};

function addBox(parent, size, position, material) {
  const mesh = new THREE.Mesh(new THREE.BoxGeometry(...size), material);
  mesh.position.set(...position);
  mesh.castShadow = true;
  mesh.receiveShadow = true;
  parent.add(mesh);
  return mesh;
}

function makeFrame(scene) {
  const frame = new THREE.Group();
  const width = CAD_MODEL.frameWidth;
  const height = CAD_MODEL.frameHeight;
  addBox(frame, [0.22, height, 0.22], [-width / 2, height / 2, 0], MATERIALS.frame);
  addBox(frame, [0.22, height, 0.22], [width / 2, height / 2, 0], MATERIALS.frame);
  addBox(frame, [width + 0.18, 0.25, 0.32], [0, height, 0], MATERIALS.beam);
  addBox(frame, [CAD_MODEL.baseWidth, CAD_MODEL.baseHeight, CAD_MODEL.baseDepth], [0, -0.12, 0], MATERIALS.frame);
  addBox(frame, [0.30, 0.34, 0.30], [0, height - 0.29, 0], MATERIALS.joint);
  // Subtle rear cross-brace makes the frame visually legible without adding mechanisms.
  addBox(frame, [0.10, 0.10, 0.10], [-0.88, 2.75, -0.35], MATERIALS.frame).rotation.z = -0.69;
  addBox(frame, [0.10, 0.10, 0.10], [0.88, 2.75, -0.35], MATERIALS.frame).rotation.z = 0.69;
  scene.add(frame);
  return { frame, pivotHeight: CAD_PIVOT_HEIGHT };
}

export class PendulumScene {
  constructor(container) {
    this.container = container;
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x0b1422);
    this.camera = new THREE.PerspectiveCamera(42, 1, 0.1, 100);
    this.camera.position.set(5.8, 4.7, 8.4);
    this.renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.25;
    container.appendChild(this.renderer.domElement);

    this.controls = new OrbitControls(this.camera, this.renderer.domElement);
    this.controls.enableDamping = true;
    this.controls.dampingFactor = 0.06;
    this.controls.target.set(0, 2.35, 0);
    this.controls.minDistance = 4;
    this.controls.maxDistance = 18;
    this.controls.maxPolarAngle = Math.PI * 0.49;

    this.scene.add(new THREE.HemisphereLight(0xa9cfff, 0x172235, 1.8));
    const key = new THREE.DirectionalLight(0xe1efff, 3.1);
    key.position.set(-4, 8, 6);
    key.castShadow = true;
    key.shadow.mapSize.set(1024, 1024);
    this.scene.add(key);
    const rim = new THREE.PointLight(0x4c96ee, 42, 18);
    rim.position.set(4, 4.5, -3);
    this.scene.add(rim);

    const grid = new THREE.GridHelper(16, 32, 0x31506f, 0x1b3048);
    grid.position.y = -0.255;
    this.scene.add(grid);
    this.grid = grid;
    this.axes = new THREE.AxesHelper(1.4);
    this.axes.position.set(-2.1, 0.03, 0.3);
    this.scene.add(this.axes);

    this.pivot = makeFrame(this.scene).pivotHeight;
    this.pivotMarker = new THREE.Mesh(new THREE.SphereGeometry(CAD_MODEL.pivotMarkerRadius, 24, 16), MATERIALS.joint);
    this.pivotMarker.position.set(0, this.pivot, 0);
    this.scene.add(this.pivotMarker);

    this.rod = new THREE.Mesh(new THREE.CylinderGeometry(CAD_MODEL.rodRadius, CAD_MODEL.rodRadius, 1, 20), MATERIALS.rod);
    this.rod.castShadow = true;
    this.scene.add(this.rod);
    this.bob = new THREE.Group();
    const shell = new THREE.Mesh(new THREE.SphereGeometry(CAD_MODEL.bobRadius, 36, 24), MATERIALS.bob);
    shell.castShadow = true;
    const band = new THREE.Mesh(new THREE.TorusGeometry(CAD_MODEL.bobRadius + 0.005, 0.018, 8, 48), MATERIALS.bobDark);
    band.rotation.x = Math.PI / 2;
    this.bob.add(shell, band);
    this.scene.add(this.bob);

    this.velocityArrow = new THREE.ArrowHelper(new THREE.Vector3(1, 0, 0), new THREE.Vector3(), 0.9, 0x5dd7a0, 0.18, 0.12);
    this.scene.add(this.velocityArrow);
    this.velocityArrow.visible = false;

    this.trailPositions = new Float32Array(3 * 160);
    this.trailGeometry = new THREE.BufferGeometry();
    this.trailAttribute = new THREE.BufferAttribute(this.trailPositions, 3);
    this.trailGeometry.setAttribute('position', this.trailAttribute);
    this.trailLine = new THREE.Line(this.trailGeometry, new THREE.LineBasicMaterial({ color: 0x6aaeff, transparent: true, opacity: 0.56 }));
    this.scene.add(this.trailLine);
    this.trailPoints = [];
    this.vectorsVisible = false;
    this.resizeObserver = new ResizeObserver(() => this.resize());
    this.resizeObserver.observe(container);
    this.resize();
    this.render();
  }

  update(state, length) {
    const bobX = length * Math.sin(state.theta);
    const bobY = this.pivot - length * Math.cos(state.theta);
    const top = new THREE.Vector3(0, this.pivot, 0);
    const bottom = new THREE.Vector3(bobX, bobY, 0);
    const direction = bottom.clone().sub(top);
    this.rod.position.copy(top).add(bottom).multiplyScalar(0.5);
    this.rod.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), direction.clone().normalize());
    this.rod.scale.set(1, direction.length(), 1);
    this.bob.position.copy(bottom);

    if (Math.abs(state.time % 0.04) < 0.009) {
      this.trailPoints.push(bottom.clone());
      if (this.trailPoints.length > 160) this.trailPoints.shift();
      this.updateTrail();
    }
    const tangent = new THREE.Vector3(Math.cos(state.theta), Math.sin(state.theta), 0).multiplyScalar(Math.sign(state.omega || 1));
    const arrowLength = Math.min(1.7, Math.max(0.35, Math.abs(state.omega) * 0.48));
    this.velocityArrow.position.copy(bottom);
    this.velocityArrow.setDirection(tangent.normalize());
    this.velocityArrow.setLength(arrowLength, 0.16, 0.12);
    this.velocityArrow.visible = this.vectorsVisible && Math.abs(state.omega) > 0.035;
  }

  updateTrail() {
    const values = this.trailPositions;
    values.fill(0);
    this.trailPoints.forEach((point, index) => {
      values[index * 3] = point.x;
      values[index * 3 + 1] = point.y;
      values[index * 3 + 2] = point.z;
    });
    this.trailAttribute.needsUpdate = true;
    this.trailGeometry.setDrawRange(0, this.trailPoints.length);
  }

  clearTrail() { this.trailPoints = []; this.updateTrail(); }
  toggleGrid() { this.grid.visible = !this.grid.visible; }
  toggleVectors() { this.vectorsVisible = !this.vectorsVisible; }

  homeCamera() {
    this.camera.position.set(5.8, 4.7, 8.4);
    this.controls.target.set(0, 2.35, 0);
    this.controls.update();
  }

  resize() {
    const width = Math.max(1, this.container.clientWidth);
    const height = Math.max(1, this.container.clientHeight);
    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(width, height, false);
  }

  render() {
    this.controls.update();
    this.renderer.render(this.scene, this.camera);
  }

  dispose() {
    this.resizeObserver?.disconnect();
    this.controls.dispose();
    this.renderer.dispose();
    this.container.replaceChildren();
  }
}
