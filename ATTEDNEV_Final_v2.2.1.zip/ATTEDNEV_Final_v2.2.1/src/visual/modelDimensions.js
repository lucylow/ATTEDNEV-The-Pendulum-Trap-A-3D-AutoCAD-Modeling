export const CAD_MODEL = Object.freeze({
  frameWidth: 3.6,
  frameHeight: 5.65,
  frameMember: 0.22,
  topBeamDepth: 0.32,
  baseWidth: 4.5,
  baseHeight: 0.24,
  baseDepth: 1.0,
  pivotOffsetFromTop: 0.46,
  pivotMarkerRadius: 0.12,
  bobRadius: 0.24,
  rodRadius: 0.035,
});

export const CAD_PIVOT_HEIGHT = CAD_MODEL.frameHeight - CAD_MODEL.pivotOffsetFromTop;
