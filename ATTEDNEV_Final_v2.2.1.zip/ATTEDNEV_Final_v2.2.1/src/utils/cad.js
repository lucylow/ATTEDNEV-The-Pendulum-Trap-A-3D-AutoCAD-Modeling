import { CAD_MODEL, CAD_PIVOT_HEIGHT } from '../visual/modelDimensions.js';

const CAD_HEADERS = [
  'entity_type', 'layer', 'component',
  'x1_m', 'y1_m', 'z1_m', 'x2_m', 'y2_m', 'z2_m',
  'width_m', 'height_m', 'depth_m', 'radius_m',
  'angle_deg', 'length_m', 'mass_kg', 'notes',
];

const fixed = (value) => Number(value.toFixed(6));
const row = (values) => Object.fromEntries(CAD_HEADERS.map((key, index) => [key, values[index] ?? '']));

export function normalizeAngles(input) {
  const values = String(input ?? '')
    .split(/[;,\s]+/)
    .map(Number)
    .filter((value) => Number.isFinite(value) && value >= -80 && value <= 80);
  return [...new Set(values.map((value) => Number(value.toFixed(2))))];
}

export function pendulumPose(length, angleDeg, pivotHeight = CAD_PIVOT_HEIGHT) {
  const theta = angleDeg * Math.PI / 180;
  return {
    x: fixed(length * Math.sin(theta)),
    y: fixed(pivotHeight - length * Math.cos(theta)),
    z: 0,
  };
}

export function buildCadRows(parameters, angles = [parameters.initialAngleDeg]) {
  const length = Number(parameters.length);
  const mass = Number(parameters.mass);
  const safeAngles = normalizeAngles(angles);
  const rows = [
    row(['BOX', 'FRAME', 'left_support', -CAD_MODEL.frameWidth / 2, CAD_MODEL.frameHeight / 2, 0, '', '', '', CAD_MODEL.frameMember, CAD_MODEL.frameHeight, CAD_MODEL.frameMember, '', '', '', '', 'Structural frame member']),
    row(['BOX', 'FRAME', 'right_support', CAD_MODEL.frameWidth / 2, CAD_MODEL.frameHeight / 2, 0, '', '', '', CAD_MODEL.frameMember, CAD_MODEL.frameHeight, CAD_MODEL.frameMember, '', '', '', '', 'Structural frame member']),
    row(['BOX', 'FRAME', 'top_cross_member', 0, CAD_MODEL.frameHeight, 0, '', '', '', CAD_MODEL.frameWidth + 0.18, 0.25, CAD_MODEL.topBeamDepth, '', '', '', '', 'Upper support beam']),
    row(['BOX', 'FRAME', 'base', 0, -0.12, 0, '', '', '', CAD_MODEL.baseWidth, CAD_MODEL.baseHeight, CAD_MODEL.baseDepth, '', '', '', '', 'Base plate']),
    row(['POINT', 'PIVOT', 'pivot', 0, CAD_PIVOT_HEIGHT, 0, '', '', '', '', '', '', CAD_MODEL.pivotMarkerRadius, '', '', '', 'Fixed rotational reference']),
  ];

  safeAngles.forEach((angleDeg, index) => {
    const pose = pendulumPose(length, angleDeg);
    const suffix = safeAngles.length > 1 ? `_position_${index + 1}` : '';
    rows.push(row(['LINE', 'PENDULUM', `rod${suffix}`, 0, CAD_PIVOT_HEIGHT, 0, pose.x, pose.y, pose.z, '', '', '', '', angleDeg, length, mass, 'Massless rigid rod centerline']));
    rows.push(row(['POINT', 'PENDULUM', `bob_center${suffix}`, pose.x, pose.y, pose.z, '', '', '', '', '', '', CAD_MODEL.bobRadius, angleDeg, length, mass, 'Rounded inert point mass']));
  });

  for (let angle = -80; angle <= 80; angle += 10) {
    const pose = pendulumPose(length, angle);
    rows.push(row(['POINT', 'SWING_ENVELOPE', 'swing_envelope_sample', pose.x, pose.y, pose.z, '', '', '', '', '', '', '', angle, length, mass, 'Static swing-envelope sample']));
  }

  return rows;
}

export function cadCsvHeaders() {
  return CAD_HEADERS;
}
