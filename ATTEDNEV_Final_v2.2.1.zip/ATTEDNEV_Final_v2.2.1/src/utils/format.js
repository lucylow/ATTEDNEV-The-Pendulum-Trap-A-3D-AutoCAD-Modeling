export const fixed = (value, digits = 3) => Number.isFinite(value) ? value.toFixed(digits) : '—';
export const formatTime = (seconds) => `${fixed(seconds, 3)} s`;
export const clamp = (value, min, max) => Math.min(max, Math.max(min, value));
export const escapeHTML = (value) => String(value).replace(/[&<>"']/g, (char) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[char]);
