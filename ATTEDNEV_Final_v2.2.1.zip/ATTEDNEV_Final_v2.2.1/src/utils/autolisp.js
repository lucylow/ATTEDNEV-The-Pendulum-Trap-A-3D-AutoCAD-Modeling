import { CAD_MODEL, CAD_PIVOT_HEIGHT } from '../visual/modelDimensions.js';
import { normalizeAngles, pendulumPose } from './cad.js';

const fmt = (value) => Number(value.toFixed(6)).toString();
const lispPoint = (x, y, z = 0) => `(list ${fmt(x)} ${fmt(y)} ${fmt(z)})`;
const safeName = (value) => String(value).replace(/[^A-Za-z0-9_.-]/g, '_');

export function generateAutoLisp(parameters, angleInput = [parameters.initialAngleDeg]) {
  const angles = normalizeAngles(Array.isArray(angleInput) ? angleInput.join(',') : angleInput);
  const selectedAngles = angles.length ? angles : [Number(parameters.initialAngleDeg) || 0];
  const length = Number(parameters.length);
  const mass = Number(parameters.mass);
  const frameWidth = CAD_MODEL.frameWidth;
  const frameHeight = CAD_MODEL.frameHeight;
  const baseWidth = CAD_MODEL.baseWidth;
  const pivot = CAD_PIVOT_HEIGHT;
  const lines = [
    '; A.T.T.E.D.N.E.V. AutoLISP geometry handoff',
    '; Angular Trajectory Tracking & Energy Dynamics Numerical Experiment Visualizer',
    '; Educational, nonfunctional pendulum visualization. No hardware or harmful mechanism.',
    `; Parameters: L=${fmt(length)} m | mass=${fmt(mass)} kg | pivot Y=${fmt(pivot)} m`,
    '; Commands: ATTEDNEVBUILD, ATTEDNEVPOSITIONS, ATTEDNEVDIMS, ATTEDNEVLAYERSETUP, ATTEDNEVHELP',
    '',
    '(vl-load-com)',
    '(defun att:pt (x y z) (list x y z))',
    '(defun att:set-layer (name color)',
    '  (command-s "_.-LAYER" "_M" name "_C" color name "")',
    '  (setvar "CLAYER" name)',
    ')',
    '(defun att:layer-color (name)',
    '  (cond ((= name "ATTEDNEV_FRAME") "140") ((= name "ATTEDNEV_PIVOT") "3") ((= name "ATTEDNEV_PENDULUM") "30") ((= name "ATTEDNEV_ENVELOPE") "4") ((= name "ATTEDNEV_DIMS") "2") (T "7"))',
    ')',
    '(defun att:layer-setup ()',
    '  (att:set-layer "ATTEDNEV_FRAME" "140")',
    '  (att:set-layer "ATTEDNEV_PIVOT" "3")',
    '  (att:set-layer "ATTEDNEV_PENDULUM" "30")',
    '  (att:set-layer "ATTEDNEV_ENVELOPE" "4")',
    '  (att:set-layer "ATTEDNEV_DIMS" "2")',
    ')',
    '(defun att:box (layer corner width height depth)',
    '  (att:set-layer layer (att:layer-color layer))',
    '  (command-s "_.BOX" corner "_L" width height depth)',
    ')',
    '(defun att:line (layer p1 p2)',
    '  (att:set-layer layer (att:layer-color layer))',
    '  (command-s "_.LINE" p1 p2 "")',
    ')',
    '(defun att:sphere (layer center radius)',
    '  (att:set-layer layer (att:layer-color layer))',
    '  (command-s "_.SPHERE" center radius)',
    ')',
    '(defun att:label (text p)',
    '  (att:set-layer "ATTEDNEV_DIMS" "2")',
    '  (command-s "_.-TEXT" "_J" "_MC" p "0.12" "0" text)',
    ')',
    `(defun att:pose (angle / r) (setq r (* angle (/ pi 180.0))) (list (* ${fmt(length)} (sin r)) (+ ${fmt(pivot)} (* -1 ${fmt(length)} (cos r))) 0.0))`,
    '(defun att:frame ()',
    `  (att:box "ATTEDNEV_FRAME" (list ${fmt(-frameWidth / 2)} 0 0) ${fmt(CAD_MODEL.frameMember)} ${fmt(frameHeight)} ${fmt(CAD_MODEL.frameMember)})`,
    `  (att:box "ATTEDNEV_FRAME" (list ${fmt(frameWidth / 2 - CAD_MODEL.frameMember)} 0 0) ${fmt(CAD_MODEL.frameMember)} ${fmt(frameHeight)} ${fmt(CAD_MODEL.frameMember)})`,
    `  (att:box "ATTEDNEV_FRAME" (list ${fmt(-(frameWidth + 0.18) / 2)} ${fmt(frameHeight - 0.125)} ${fmt(-CAD_MODEL.topBeamDepth / 2)}) ${fmt(frameWidth + 0.18)} 0.25 ${fmt(CAD_MODEL.topBeamDepth)})`,
    `  (att:box "ATTEDNEV_FRAME" (list ${fmt(-baseWidth / 2)} ${fmt(-CAD_MODEL.baseHeight)} ${fmt(-CAD_MODEL.baseDepth / 2)}) ${fmt(baseWidth)} ${fmt(CAD_MODEL.baseHeight)} ${fmt(CAD_MODEL.baseDepth)})`,
    `  (att:sphere "ATTEDNEV_PIVOT" ${lispPoint(0, pivot, 0)} ${fmt(CAD_MODEL.pivotMarkerRadius)})`,
    `  (att:label "FRAME ${fmt(frameWidth)}m x ${fmt(frameHeight)}m" ${lispPoint(0, frameHeight + 0.25, 0)})`,
    ')',
    '(defun att:pendulum (angle tag / bob)',
    '  (setq bob (att:pose angle))',
    `  (att:line "ATTEDNEV_PENDULUM" ${lispPoint(0, pivot, 0)} bob)`,
    `  (att:sphere "ATTEDNEV_PENDULUM" bob ${fmt(CAD_MODEL.bobRadius)})`,
    '  (att:label (strcat "ANGLE " (rtos angle 2 2) " deg / " tag) bob)',
    ')',
    '(defun att:envelope ()',
  ];

  for (let angle = -80; angle <= 80; angle += 10) {
    const pose = pendulumPose(length, angle, pivot);
    lines.push(`  (att:sphere "ATTEDNEV_ENVELOPE" ${lispPoint(pose.x, pose.y, pose.z)} 0.035)`);
  }
  lines.push(')', '', '(defun att:dimensions ()', `  (att:label "FRAME WIDTH = ${fmt(frameWidth)} m" ${lispPoint(0, -0.38, 0)})`, `  (att:label "FRAME HEIGHT = ${fmt(frameHeight)} m" ${lispPoint(frameWidth / 2 + 0.38, frameHeight / 2, 0)})`, `  (att:label "PIVOT = (0, ${fmt(pivot)}, 0)" ${lispPoint(0, pivot + 0.38, 0)})`, `  (att:label "PENDULUM LENGTH = ${fmt(length)} m" ${lispPoint(0, pivot - length - 0.38, 0)})`, `  (att:label "BOB MASS = ${fmt(mass)} kg" ${lispPoint(0, pivot - length - 0.62, 0)})`, `  (att:label "INITIAL ANGLE = ${fmt(selectedAngles[0])} deg" ${lispPoint(0, pivot - length - 0.86, 0)})`, ')', '', '(defun c:ATTEDNEVLAYERSETUP ()', '  (att:layer-setup)', '  (princ "\\nA.T.T.E.D.N.E.V. layers created and color-coded.")', '  (princ)', ')', '', '(defun c:ATTEDNEVBUILD ()', '  (att:layer-setup)', '  (att:frame)', `  (att:pendulum ${fmt(selectedAngles[0])} "CURRENT")`, '  (att:envelope)', '  (att:dimensions)', '  (princ "\\nA.T.T.E.D.N.E.V. frame, current pendulum, envelope, and annotations created.")', '  (princ)', ')', '', '(defun c:ATTEDNEVPOSITIONS ()', '  (att:layer-setup)', '  (att:frame)');
  selectedAngles.forEach((angle, index) => lines.push(`  (att:pendulum ${fmt(angle)} "POSITION_${index + 1}")`));
  lines.push('  (att:envelope)', '  (att:dimensions)', '  (princ "\\nA.T.T.E.D.N.E.V. static pendulum positions, envelope, and annotations created.")', '  (princ)', ')', '', '(defun c:ATTEDNEVDIMS ()', '  (att:dimensions)', '  (princ "\\nA.T.T.E.D.N.E.V. annotations added.")', '  (princ)', ')', '', '(defun c:ATTEDNEVHELP ()', '  (princ "\\nCommands: ATTEDNEVBUILD | ATTEDNEVPOSITIONS | ATTEDNEVDIMS | ATTEDNEVLAYERSETUP | ATTEDNEVHELP")', '  (princ "\\nLayers: ATTEDNEV_FRAME, ATTEDNEV_PIVOT, ATTEDNEV_PENDULUM, ATTEDNEV_ENVELOPE, ATTEDNEV_DIMS")', '  (princ)', ')', '', '(princ "\\nA.T.T.E.D.N.E.V. AutoLISP loaded. Type ATTEDNEVBUILD to create the educational model.")', '(princ)', '');

  return lines.join('\n');
}

export function autoLispFilename(parameters) {
  const angle = safeName(Number(parameters.initialAngleDeg).toFixed(0));
  return `attednev_pendulum_${angle}deg.lsp`;
}
