import { fixed } from '../utils/format.js';

export class StudyPanels {
  constructor() {
    this.frequencyCanvas = document.getElementById('frequency-chart');
    this.frequencySummary = document.getElementById('frequency-summary');
    this.frequencyTable = document.getElementById('frequency-table');
    this.convergenceTable = document.getElementById('convergence-table');
  }

  reset() {
    this.frequencySummary.textContent = 'Set the virtual drive amplitude above zero, then run the sweep.';
    this.frequencyTable.innerHTML = '<div class="study-placeholder">No sweep results yet.</div>';
    this.convergenceTable.innerHTML = '<div class="study-placeholder">Run the check to compare numerical step sizes.</div>';
    const ctx = this.frequencyCanvas.getContext('2d');
    ctx.clearRect(0, 0, this.frequencyCanvas.width, this.frequencyCanvas.height);
  }

  renderFrequencySweep(report) {
    const { results, peak, settings } = report;
    this.frequencySummary.innerHTML = `Peak sampled response: <b>${fixed(peak.amplitudeDeg, 2)}°</b> at <b>${fixed(peak.frequencyHz, 3)} Hz</b>. Drive amplitude ${fixed(settings.driveAmplitude, 2)} rad/s²; last ${settings.windowSeconds.toFixed(1)} s used for the amplitude estimate.`;
    this.frequencyTable.innerHTML = `<table class="study-table"><thead><tr><th>Frequency (Hz)</th><th>Response amplitude (°)</th></tr></thead><tbody>${results.map((row) => `<tr><td>${fixed(row.frequencyHz, 3)}</td><td>${fixed(row.amplitudeDeg, 3)}</td></tr>`).join('')}</tbody></table>`;
    this.drawFrequencyChart(results, peak);
  }

  drawFrequencyChart(results, peak) {
    const canvas = this.frequencyCanvas;
    const rect = canvas.getBoundingClientRect();
    const ratio = Math.min(window.devicePixelRatio || 1, 2);
    canvas.width = Math.max(1, Math.floor(rect.width * ratio));
    canvas.height = Math.max(1, Math.floor(rect.height * ratio));
    const ctx = canvas.getContext('2d');
    ctx.scale(ratio, ratio);
    const width = rect.width;
    const height = rect.height;
    const pad = { l: 48, r: 16, t: 14, b: 32 };
    const maxX = results.at(-1).frequencyHz;
    const minX = results[0].frequencyHz;
    const maxY = Math.max(0.1, ...results.map((item) => item.amplitudeDeg)) * 1.12;
    const x = (v) => pad.l + (v - minX) / (maxX - minX) * (width - pad.l - pad.r);
    const y = (v) => height - pad.b - v / maxY * (height - pad.t - pad.b);
    ctx.clearRect(0, 0, width, height);
    ctx.strokeStyle = 'rgba(146,171,202,.17)';
    ctx.fillStyle = '#8fa5bf';
    ctx.font = '10px system-ui';
    ctx.lineWidth = 1;
    for (let i = 0; i <= 4; i += 1) {
      const value = maxY * i / 4;
      const py = y(value);
      ctx.beginPath(); ctx.moveTo(pad.l, py); ctx.lineTo(width - pad.r, py); ctx.stroke();
      ctx.fillText(value.toFixed(1), 7, py + 3);
    }
    ctx.beginPath();
    results.forEach((item, index) => index ? ctx.lineTo(x(item.frequencyHz), y(item.amplitudeDeg)) : ctx.moveTo(x(item.frequencyHz), y(item.amplitudeDeg)));
    ctx.strokeStyle = '#72b7ff'; ctx.lineWidth = 2.4; ctx.stroke();
    ctx.fillStyle = '#72b7ff';
    results.forEach((item) => { ctx.beginPath(); ctx.arc(x(item.frequencyHz), y(item.amplitudeDeg), 2.5, 0, Math.PI * 2); ctx.fill(); });
    ctx.fillStyle = '#f4b36c'; ctx.beginPath(); ctx.arc(x(peak.frequencyHz), y(peak.amplitudeDeg), 5, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = '#8fa5bf';
    ctx.fillText(`${minX.toFixed(2)} Hz`, pad.l, height - 8);
    ctx.fillText(`${maxX.toFixed(2)} Hz`, width - pad.r - 44, height - 8);
    ctx.fillText('Amplitude (°)', 8, 12);
    ctx.fillText('Frequency response · half peak-to-peak angle', pad.l + 8, 12);
  }

  renderConvergence(rows) {
    this.convergenceTable.innerHTML = `<table class="study-table"><thead><tr><th>Step (ms)</th><th>Steps</th><th>Angle error (°)</th><th>Rate error (rad/s)</th></tr></thead><tbody>${rows.map((row) => `<tr class="${row.reference ? 'reference-row' : ''}"><td>${fixed(row.dt * 1000, 3)}</td><td>${row.steps.toLocaleString()}</td><td>${row.reference ? 'Reference' : fixed(row.angleErrorDeg, 6)}</td><td>${row.reference ? '—' : fixed(row.omegaErrorRadS, 7)}</td></tr>`).join('')}</tbody></table><p class="study-note">Errors are measured against the finest step in this run (${fixed(rows.at(-1).dt * 1000, 3)} ms) at the same final simulation time.</p>`;
  }
}
