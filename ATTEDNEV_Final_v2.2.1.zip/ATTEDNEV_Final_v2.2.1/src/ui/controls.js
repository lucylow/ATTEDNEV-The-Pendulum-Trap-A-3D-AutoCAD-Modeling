import { APP_CONFIG } from '../config.js';

const BINDINGS = {
  length: ['length-range', 'length-output', (v) => `${v.toFixed(2)} m`],
  mass: ['mass-range', 'mass-output', (v) => `${v.toFixed(1)} kg`],
  gravity: ['gravity-range', 'gravity-output', (v) => `${v.toFixed(2)} m/s²`],
  damping: ['damping-range', 'damping-output', (v) => `${v.toFixed(3)} s⁻¹`],
  initialAngleDeg: ['angle-range', 'angle-output', (v) => `${v.toFixed(1)}°`],
  driveAmplitude: ['drive-amplitude-range', 'drive-amplitude-output', (v) => `${v.toFixed(2)} rad/s²`],
  driveFrequencyHz: ['drive-frequency-range', 'drive-frequency-output', (v) => `${v.toFixed(2)} Hz`],
  timeScale: ['time-scale', 'time-scale-output', (v) => `${v.toFixed(1)}×`],
};

export class ParameterControls {
  constructor(onParametersChanged, onTimeScaleChanged) {
    this.onParametersChanged = onParametersChanged;
    this.onTimeScaleChanged = onTimeScaleChanged;
    this.values = { ...APP_CONFIG.defaults };
    this.inputs = Object.fromEntries(Object.entries(BINDINGS).map(([key, [id]]) => [key, document.getElementById(id)]));
    this.outputs = Object.fromEntries(Object.entries(BINDINGS).map(([key, [, id]]) => [key, document.getElementById(id)]));
    this.bind();
    this.sync();
  }

  bind() {
    for (const key of Object.keys(BINDINGS)) {
      this.inputs[key].addEventListener('input', () => {
        const value = Number(this.inputs[key].value);
        this.values[key] = value;
        this.outputs[key].textContent = BINDINGS[key][2](value);
        if (key === 'timeScale') this.onTimeScaleChanged(value);
        else this.onParametersChanged({ [key]: value }, true);
      });
    }
    document.getElementById('defaults-button').addEventListener('click', () => this.applyPreset(APP_CONFIG.defaults));
    document.getElementById('preset-select').addEventListener('change', (event) => {
      const preset = APP_CONFIG.presets[event.target.value];
      if (preset) this.applyPreset(preset);
    });
    document.getElementById('integrator-select').addEventListener('change', (event) => {
      this.values.integrator = event.target.value;
    });
    document.getElementById('sample-rate').addEventListener('change', (event) => {
      this.values.sampleInterval = Number(event.target.value);
      this.onParametersChanged({ sampleInterval: this.values.sampleInterval }, false);
    });
  }

  applyPreset(preset) {
    this.values = { ...this.values, ...preset };
    this.sync();
    const changed = { ...preset };
    delete changed.timeScale;
    this.onParametersChanged(changed, Object.hasOwn(preset, 'initialAngleDeg'));
    if (preset.timeScale !== undefined) this.onTimeScaleChanged(preset.timeScale);
  }

  sync() {
    for (const key of Object.keys(BINDINGS)) {
      const [inputId, outputId, formatter] = BINDINGS[key];
      if (this.values[key] === undefined) continue;
      document.getElementById(inputId).value = this.values[key];
      document.getElementById(outputId).textContent = formatter(this.values[key]);
    }
    const sampling = document.getElementById('sample-rate');
    if (sampling) sampling.value = String(this.values.sampleInterval);
    const integrator = document.getElementById('integrator-select');
    if (integrator && this.values.integrator) integrator.value = this.values.integrator;
  }

  setLocked(locked) {
    for (const [key, input] of Object.entries(this.inputs)) input.disabled = locked && key !== 'timeScale';
    document.getElementById('preset-select').disabled = locked;
    document.getElementById('sample-rate').disabled = locked;
    document.getElementById('integrator-select').disabled = locked;
    document.getElementById('step-size-select').disabled = locked;
    document.getElementById('defaults-button').disabled = locked;
  }

  get valuesSnapshot() { return { ...this.values }; }
}
