const SERIES = {
  angle: { key: 'angleDeg', label: 'ANGLE', unit: '°', color: '#76b6ff' },
  velocity: { key: 'omega', label: 'ANGULAR VELOCITY', unit: 'rad/s', color: '#5dd7a0' },
  energy: { key: 'total', label: 'TOTAL ENERGY', unit: 'J', color: '#ffad72' },
};

export class ResponseChart {
  constructor(canvas, emptyElement) {
    this.canvas = canvas;
    this.context = canvas.getContext('2d');
    this.emptyElement = emptyElement;
    this.mode = 'angle';
    this.samples = [];
    this.windowSeconds = 20;
    this.resizeObserver = new ResizeObserver(() => this.draw());
    this.resizeObserver.observe(canvas);
  }

  setMode(mode) {
    if (SERIES[mode]) this.mode = mode;
    this.draw();
  }

  setSamples(samples) {
    this.samples = samples;
    this.emptyElement.classList.toggle('hidden', samples.length > 1);
    this.draw();
  }

  draw() {
    const rect = this.canvas.getBoundingClientRect();
    if (!rect.width || !rect.height) return;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const width = Math.round(rect.width * dpr);
    const height = Math.round(rect.height * dpr);
    if (this.canvas.width !== width || this.canvas.height !== height) {
      this.canvas.width = width;
      this.canvas.height = height;
    }
    const ctx = this.context;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    const w = rect.width;
    const h = rect.height;
    ctx.clearRect(0, 0, w, h);
    const margin = { left: 43, right: 10, top: 12, bottom: 24 };
    const plotW = w - margin.left - margin.right;
    const plotH = h - margin.top - margin.bottom;
    if (plotW <= 0 || plotH <= 0) return;

    const series = SERIES[this.mode];
    const samples = this.samples;
    const lastTime = samples.at(-1)?.time ?? 0;
    const startTime = Math.max(0, lastTime - this.windowSeconds);
    const visible = samples.filter((sample) => sample.time >= startTime);
    const values = visible.map((sample) => sample[series.key]).filter(Number.isFinite);
    let min = values.length ? Math.min(...values) : -1;
    let max = values.length ? Math.max(...values) : 1;
    if (Math.abs(max - min) < 1e-8) { max += 1; min -= 1; }
    const pad = (max - min) * 0.16;
    min -= pad;
    max += pad;
    if (this.mode === 'angle') {
      min = Math.min(min, -5);
      max = Math.max(max, 5);
    }
    const y = (value) => margin.top + (max - value) / (max - min) * plotH;
    const x = (time) => margin.left + (time - startTime) / Math.max(1, this.windowSeconds) * plotW;

    ctx.strokeStyle = '#24364c';
    ctx.lineWidth = 1;
    ctx.fillStyle = '#7188a4';
    ctx.font = '9px "DM Mono", monospace';
    ctx.textAlign = 'right';
    ctx.textBaseline = 'middle';
    for (let i = 0; i <= 4; i += 1) {
      const value = min + (max - min) * i / 4;
      const py = y(value);
      ctx.beginPath(); ctx.moveTo(margin.left, py); ctx.lineTo(w - margin.right, py); ctx.stroke();
      ctx.fillText(value.toFixed(1), margin.left - 7, py);
    }
    ctx.textAlign = 'center';
    ctx.textBaseline = 'top';
    for (let i = 0; i <= 4; i += 1) {
      const time = startTime + this.windowSeconds * i / 4;
      const px = x(time);
      ctx.beginPath(); ctx.moveTo(px, margin.top); ctx.lineTo(px, margin.top + plotH); ctx.stroke();
      ctx.fillText(time.toFixed(1), px, margin.top + plotH + 7);
    }

    if (visible.length > 1) {
      ctx.beginPath();
      visible.forEach((sample, index) => {
        const px = x(sample.time);
        const py = y(sample[series.key]);
        if (index === 0) ctx.moveTo(px, py); else ctx.lineTo(px, py);
      });
      ctx.strokeStyle = series.color;
      ctx.lineWidth = 1.8;
      ctx.lineJoin = 'round';
      ctx.stroke();
      const last = visible.at(-1);
      ctx.beginPath(); ctx.arc(x(last.time), y(last[series.key]), 3, 0, Math.PI * 2);
      ctx.fillStyle = series.color; ctx.fill();
    }
    ctx.save();
    ctx.translate(11, margin.top + plotH / 2);
    ctx.rotate(-Math.PI / 2);
    ctx.fillStyle = '#8197b2';
    ctx.textAlign = 'center';
    ctx.font = '8px "DM Mono", monospace';
    ctx.fillText(`${series.label} (${series.unit})`, 0, 0);
    ctx.restore();
  }

  dispose() { this.resizeObserver?.disconnect(); }
}
