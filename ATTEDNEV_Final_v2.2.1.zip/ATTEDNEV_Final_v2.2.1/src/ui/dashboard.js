import { fixed, escapeHTML } from '../utils/format.js';

export class Dashboard {
  constructor() {
    this.el = {
      time: document.querySelector('#metric-time'),
      angle: document.querySelector('#metric-angle'),
      omega: document.querySelector('#metric-omega'),
      energy: document.querySelector('#metric-energy'),
      runState: document.querySelector('#run-state'),
      runButton: document.querySelector('#run-button'),
      livePill: document.querySelector('.live-pill'),
      lengthReadout: document.querySelector('#model-readout'),
      sampleCount: document.querySelector('#sample-count'),
      eventLog: document.querySelector('#event-log'),
      triggerList: document.querySelector('#trigger-list'),
      triggerCount: document.querySelector('#trigger-count'),
      chartRange: document.querySelector('#chart-range-label'),
    };
  }

  setRunning(running) {
    this.el.runState.textContent = running ? 'RUNNING' : 'PAUSED';
    this.el.livePill.classList.toggle('running', running);
    this.el.runButton.innerHTML = running ? 'Ⅱ <span>Pause simulation</span>' : '▶ <span>Run simulation</span>';
    this.el.runButton.classList.toggle('btn-primary', !running);
  }

  updateMetrics(sample, parameters) {
    this.el.time.innerHTML = `${fixed(sample.time, 3)} <small>s</small>`;
    this.el.angle.innerHTML = `${fixed(sample.angleDeg, 2)} <small>°</small>`;
    this.el.omega.innerHTML = `${fixed(sample.omega, 3)} <small>rad/s</small>`;
    this.el.energy.innerHTML = `${fixed(sample.total, 2)} <small>J</small>`;
    this.el.lengthReadout.innerHTML = `L = ${fixed(parameters.length, 2)} m&nbsp;&nbsp; / &nbsp;&nbsp;θ = ${fixed(sample.angleDeg, 2)}°`;
  }

  updateSampleCount(count) { this.el.sampleCount.textContent = `${count.toLocaleString()} samples`; }

  renderTriggers(triggers) {
    this.el.triggerCount.textContent = `${triggers.filter((trigger) => trigger.fired).length} FIRED`;
    this.el.triggerList.innerHTML = triggers.map((trigger) => `
      <div class="trigger-row" data-trigger="${escapeHTML(trigger.id)}">
        <i class="trigger-bullet"></i>
        <div><div class="trigger-name">${escapeHTML(trigger.name)}</div><div class="trigger-condition">${['zero-crossing', 'turning-point'].includes(trigger.kind) ? (trigger.kind === 'zero-crossing' ? 'θ crosses 0°' : 'ω changes sign') : `${trigger.direction === 'below' ? '≤' : '≥'} <input class="trigger-threshold" type="number" min="0" step="${trigger.kind === 'angle' ? '1' : '0.05'}" value="${trigger.threshold}" data-trigger-threshold="${escapeHTML(trigger.id)}" aria-label="${escapeHTML(trigger.name)} threshold" /> ${trigger.kind === 'angle' ? '°' : trigger.kind === 'omega' ? 'rad/s' : trigger.kind === 'energy' ? 'J' : 's'}`}</div></div>
        <label class="trigger-status ${trigger.fired ? 'fired' : ''}"><input type="checkbox" data-trigger-enabled="${escapeHTML(trigger.id)}" ${trigger.enabled ? 'checked' : ''} aria-label="Enable ${escapeHTML(trigger.name)}" /> ${trigger.fired ? 'FIRED' : trigger.enabled ? 'ARMED' : 'OFF'}</label>
      </div>`).join('');
  }

  renderEvents(events) {
    if (!events.length) {
      this.el.eventLog.innerHTML = '<div class="log-empty">No events recorded in this run.</div>';
      return;
    }
    this.el.eventLog.innerHTML = [...events].reverse().map((event) => `
      <div class="log-entry"><time>${fixed(event.time, 2)}s</time><span><b>${escapeHTML(event.name)}</b> — ${escapeHTML(event.message)}</span></div>`).join('');
  }

  updateRangeLabel(time) {
    this.el.chartRange.textContent = `${Math.max(0, time - 20).toFixed(1)}–${time.toFixed(1)} s WINDOW`;
  }
}
