export const APP_CONFIG = Object.freeze({
  title: 'A.T.T.E.D.N.E.V. — Angular Trajectory Tracking & Energy Dynamics Numerical Experiment Visualizer',
  version: '2.2.1',
  integrationStep: 1 / 120,
  maxFrameDelta: 0.05,
  maxSubstepsPerFrame: 48,
  historyLimit: 12000,
  triggerDebounceSeconds: 0.35,
  defaults: Object.freeze({
    length: 2.4,
    mass: 8,
    gravity: 9.81,
    damping: 0.025,
    initialAngleDeg: 35,
    timeScale: 1,
    sampleInterval: 1 / 60,
    driveAmplitude: 0,
    driveFrequencyHz: 0.65,
    drivePhaseDeg: 0,
    integrator: 'rk4',
  }),
  presets: Object.freeze({
    baseline: { length: 2.4, mass: 8, gravity: 9.81, damping: 0.025, initialAngleDeg: 35, driveAmplitude: 0, driveFrequencyHz: 0.65, drivePhaseDeg: 0 },
    'low-gravity': { length: 2.4, mass: 8, gravity: 1.62, damping: 0.025, initialAngleDeg: 35, driveAmplitude: 0, driveFrequencyHz: 0.65, drivePhaseDeg: 0 },
    'high-damping': { length: 2.4, mass: 8, gravity: 9.81, damping: 0.28, initialAngleDeg: 35, driveAmplitude: 0, driveFrequencyHz: 0.65, drivePhaseDeg: 0 },
    'long-arm': { length: 4.6, mass: 12, gravity: 9.81, damping: 0.02, initialAngleDeg: 35, driveAmplitude: 0, driveFrequencyHz: 0.65, drivePhaseDeg: 0 },
    'small-angle': { length: 2.4, mass: 8, gravity: 9.81, damping: 0.025, initialAngleDeg: 5, driveAmplitude: 0, driveFrequencyHz: 0.65, drivePhaseDeg: 0 },
    'resonance-study': { length: 1.5, mass: 5, gravity: 9.81, damping: 0.06, initialAngleDeg: 2, driveAmplitude: 1.1, driveFrequencyHz: 0.40, drivePhaseDeg: 0 },
  }),
});

export const TRIGGER_DEFAULTS = Object.freeze([
  { id: 'angle-limit', name: 'Angular displacement', detail: 'Absolute angle crosses 25°', enabled: true, kind: 'angle', threshold: 25, direction: 'above', color: '#69d8e8', repeat: false },
  { id: 'speed-limit', name: 'Angular speed', detail: 'Absolute angular speed crosses 1.50 rad/s', enabled: true, kind: 'omega', threshold: 1.5, direction: 'above', color: '#ff9c61', repeat: false },
  { id: 'energy-limit', name: 'Mechanical energy', detail: 'Energy falls below 10.0 J', enabled: true, kind: 'energy', threshold: 10, direction: 'below', color: '#b69aff', repeat: false },
  { id: 'time-limit', name: 'Elapsed time', detail: 'Simulation reaches 5.00 s', enabled: true, kind: 'time', threshold: 5, direction: 'above', color: '#5dd7a0', repeat: false },
  { id: 'center-crossing', name: 'Center crossing', detail: 'Pendulum crosses the vertical equilibrium line', enabled: true, kind: 'zero-crossing', color: '#74a9ff', repeat: true },
  { id: 'turning-point', name: 'Turning point', detail: 'Angular velocity changes sign', enabled: false, kind: 'turning-point', color: '#e7c66d', repeat: true },
]);
