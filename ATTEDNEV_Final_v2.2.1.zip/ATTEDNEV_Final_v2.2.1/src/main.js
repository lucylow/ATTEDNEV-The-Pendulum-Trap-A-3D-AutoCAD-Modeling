import { PendulumLabApp } from './app.js';
import { CanvasPendulumScene } from './visual/fallback.js';

async function boot() {
  let scene;
  try {
    // Dynamic import lets the app fall back if the CDN module or WebGL is unavailable.
    const { PendulumScene } = await import('./visual/scene.js');
    scene = new PendulumScene(document.getElementById('three-view'));
  } catch (renderError) {
    console.warn('Three.js renderer unavailable; selecting the 2D schematic fallback.', renderError);
    scene = new CanvasPendulumScene(document.getElementById('three-view'));
  }
  window.pendulumLab = new PendulumLabApp({ scene });
}

boot().catch((error) => {
  console.error(error);
  const target = document.getElementById('three-view');
  if (target) target.innerHTML = '<div role="alert" style="padding:24px;color:#ffb3b3;font:12px monospace">The simulator could not start. Check the browser console and reload the page.</div>';
});
