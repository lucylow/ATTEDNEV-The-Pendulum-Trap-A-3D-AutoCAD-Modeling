/** Simulation-only condition monitor. Events are local log records, never hardware commands. */
export class TriggerEngine {
  constructor(definitions = [], options = {}) {
    this.definitions = definitions.map((item) => ({ ...item, fired: false, lastFireTime: -Infinity }));
    this.debounceSeconds = options.debounceSeconds ?? 0.35;
    this.previousSample = null;
  }

  configure(id, patch) {
    const trigger = this.definitions.find((item) => item.id === id);
    if (!trigger) return false;
    Object.assign(trigger, patch);
    if (Object.hasOwn(patch, 'enabled') && !patch.enabled) trigger.fired = false;
    if (Object.hasOwn(patch, 'threshold')) trigger.fired = false;
    return true;
  }

  reset() {
    for (const trigger of this.definitions) {
      trigger.fired = false;
      trigger.lastFireTime = -Infinity;
    }
    this.previousSample = null;
  }

  readValue(trigger, sample) {
    switch (trigger.kind) {
      case 'angle': return Math.abs(sample.angleDeg);
      case 'omega': return Math.abs(sample.omega);
      case 'energy': return sample.total;
      case 'time': return sample.time;
      case 'zero-crossing': return sample.theta;
      case 'turning-point': return sample.omega;
      default: return NaN;
    }
  }

  isSatisfied(trigger, value, sample, previous) {
    if (trigger.kind === 'zero-crossing') {
      return Boolean(previous && ((previous.theta < 0 && sample.theta >= 0) || (previous.theta > 0 && sample.theta <= 0)));
    }
    if (trigger.kind === 'turning-point') {
      return Boolean(previous && ((previous.omega < 0 && sample.omega >= 0) || (previous.omega > 0 && sample.omega <= 0)));
    }
    return trigger.direction === 'below' ? value <= trigger.threshold : value >= trigger.threshold;
  }

  evaluate(sample) {
    const events = [];
    const previous = this.previousSample;
    for (const trigger of this.definitions) {
      if (!trigger.enabled) continue;
      const value = this.readValue(trigger, sample);
      const satisfied = this.isSatisfied(trigger, value, sample, previous);
      const canRepeat = trigger.repeat && sample.time - trigger.lastFireTime >= this.debounceSeconds;
      if (satisfied && (!trigger.fired || canRepeat)) {
        trigger.fired = true;
        trigger.lastFireTime = sample.time;
        const thresholdText = Number.isFinite(trigger.threshold) ? ` threshold ${trigger.threshold.toFixed(3)}` : '';
        const transition = trigger.kind === 'zero-crossing' ? 'crossed equilibrium' : trigger.kind === 'turning-point' ? 'reached a turning point' : `reached${thresholdText}`;
        events.push({
          id: trigger.id,
          name: trigger.name,
          kind: trigger.kind,
          time: sample.time,
          value,
          threshold: trigger.threshold ?? null,
          message: `${trigger.name}: ${transition} (value ${value.toFixed(3)})`,
        });
      }
    }
    this.previousSample = { time: sample.time, theta: sample.theta, omega: sample.omega };
    return events;
  }

  get count() { return this.definitions.length; }
}
