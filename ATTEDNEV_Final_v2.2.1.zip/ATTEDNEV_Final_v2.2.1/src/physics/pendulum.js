/**
 * Nonlinear, single-degree-of-freedom pendulum with optional sinusoidal base torque.
 * State: theta (rad) measured from downward vertical; omega (rad/s).
 * The rod is rigid and massless; the bob is a point mass. Damping is linear
 * in angular velocity. The drive is a virtual angular-acceleration input only.
 *
 * theta'' = -(g/L) sin(theta) - c theta' + A sin(2 pi f t + phi)
 */
const INTEGRATORS = ['rk4', 'semi-implicit', 'euler', 'verlet'];

function validateParameters(parameters) {
  for (const key of ['length', 'mass', 'gravity']) {
    if (!Number.isFinite(parameters[key]) || parameters[key] <= 0) {
      throw new RangeError(`${key} must be a positive finite number`);
    }
  }
  if (!Number.isFinite(parameters.initialAngleDeg)) throw new RangeError('initialAngleDeg must be finite');
  if (parameters.sampleInterval !== undefined && (!Number.isFinite(parameters.sampleInterval) || parameters.sampleInterval <= 0)) {
    throw new RangeError('sampleInterval must be a positive finite number');
  }
  for (const key of ['damping', 'driveAmplitude', 'driveFrequencyHz']) {
    const value = parameters[key] ?? 0;
    if (!Number.isFinite(value) || value < 0) {
      throw new RangeError(`${key} must be a non-negative finite number`);
    }
  }
  const phase = parameters.drivePhaseDeg ?? 0;
  if (!Number.isFinite(phase)) throw new RangeError('drivePhaseDeg must be finite');
}

export class PendulumSolver {
  constructor(parameters) {
    validateParameters(parameters);
    this.parameters = { driveAmplitude: 0, driveFrequencyHz: 0, drivePhaseDeg: 0, ...parameters };
    this.integrator = parameters.integrator || 'rk4';
    this.setIntegrator(this.integrator);
    this.state = { theta: parameters.initialAngleDeg * Math.PI / 180, omega: 0 };
    this.time = 0;
    this.lastAcceleration = this.acceleration(this.state.theta, this.state.omega, 0);
  }

  setParameters(next) {
    const merged = { ...this.parameters, ...next };
    validateParameters(merged);
    this.parameters = merged;
    if (next.integrator) this.setIntegrator(next.integrator);
    this.lastAcceleration = this.acceleration(this.state.theta, this.state.omega, this.time);
  }

  setIntegrator(name) {
    if (!INTEGRATORS.includes(name)) throw new RangeError(`Unknown integrator: ${name}`);
    this.integrator = name;
  }

  reset(angleDeg = this.parameters.initialAngleDeg) {
    if (!Number.isFinite(angleDeg)) throw new RangeError('Initial angle must be finite');
    this.state = { theta: angleDeg * Math.PI / 180, omega: 0 };
    this.time = 0;
    this.lastAcceleration = this.acceleration(this.state.theta, this.state.omega, 0);
  }

  driveAcceleration(time) {
    const { driveAmplitude = 0, driveFrequencyHz = 0, drivePhaseDeg = 0 } = this.parameters;
    if (driveAmplitude === 0 || driveFrequencyHz === 0) return 0;
    const phase = 2 * Math.PI * driveFrequencyHz * time + drivePhaseDeg * Math.PI / 180;
    return driveAmplitude * Math.sin(phase);
  }

  acceleration(theta, omega, time = this.time) {
    const { gravity, length, damping } = this.parameters;
    return -(gravity / length) * Math.sin(theta) - damping * omega + this.driveAcceleration(time);
  }

  derivative(state, time) {
    return { theta: state.omega, omega: this.acceleration(state.theta, state.omega, time) };
  }

  /** Advance by one positive finite step using the selected numerical method. */
  step(dt) {
    if (!(dt > 0) || !Number.isFinite(dt)) throw new RangeError('dt must be a positive finite number');
    const s = this.state;
    const t = this.time;
    const add = (a, b, scale) => ({ theta: a.theta + b.theta * scale, omega: a.omega + b.omega * scale });

    if (this.integrator === 'euler') {
      const d = this.derivative(s, t);
      s.theta += d.theta * dt;
      s.omega += d.omega * dt;
    } else if (this.integrator === 'semi-implicit') {
      s.omega += this.acceleration(s.theta, s.omega, t) * dt;
      s.theta += s.omega * dt;
    } else if (this.integrator === 'verlet') {
      // Strang-split damped velocity Verlet: exact half damping steps around
      // a conservative kick-drift-kick update. Drive phase is evaluated at
      // both interval endpoints. This is more consistent than averaging a
      // damped acceleration with an unchanged velocity.
      const halfDamping = Math.exp(-this.parameters.damping * dt / 2);
      const omegaDamped = s.omega * halfDamping;
      const conservative0 = -(this.parameters.gravity / this.parameters.length) * Math.sin(s.theta) + this.driveAcceleration(t);
      const nextTheta = s.theta + omegaDamped * dt + 0.5 * conservative0 * dt * dt;
      const conservative1 = -(this.parameters.gravity / this.parameters.length) * Math.sin(nextTheta) + this.driveAcceleration(t + dt);
      const omegaKick = omegaDamped + 0.5 * (conservative0 + conservative1) * dt;
      s.theta = nextTheta;
      s.omega = omegaKick * halfDamping;
    } else {
      const k1 = this.derivative(s, t);
      const k2 = this.derivative(add(s, k1, dt / 2), t + dt / 2);
      const k3 = this.derivative(add(s, k2, dt / 2), t + dt / 2);
      const k4 = this.derivative(add(s, k3, dt), t + dt);
      s.theta += (dt / 6) * (k1.theta + 2 * k2.theta + 2 * k3.theta + k4.theta);
      s.omega += (dt / 6) * (k1.omega + 2 * k2.omega + 2 * k3.omega + k4.omega);
    }

    this.time += dt;
    this.lastAcceleration = this.acceleration(s.theta, s.omega, this.time);
    return this.snapshot();
  }

  snapshot() {
    const { length } = this.parameters;
    const theta = this.state.theta;
    return {
      time: this.time,
      theta,
      omega: this.state.omega,
      alpha: this.lastAcceleration,
      driveAlpha: this.driveAcceleration(this.time),
      angleDeg: theta * 180 / Math.PI,
      speed: length * this.state.omega,
      x: length * Math.sin(theta),
      y: -length * Math.cos(theta),
    };
  }
}

export function estimateSmallAnglePeriod(length, gravity) {
  if (!Number.isFinite(length) || !Number.isFinite(gravity) || length <= 0 || gravity <= 0) {
    throw new RangeError('Length and gravity must be positive finite numbers');
  }
  return 2 * Math.PI * Math.sqrt(length / gravity);
}
