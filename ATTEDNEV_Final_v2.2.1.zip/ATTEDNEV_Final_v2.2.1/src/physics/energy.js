/** Energy utilities. Potential energy is zero at the lowest point. */
export function calculateEnergy(state, parameters) {
  const { mass, gravity, length } = parameters;
  const kinetic = 0.5 * mass * (length * state.omega) ** 2;
  const potential = mass * gravity * length * (1 - Math.cos(state.theta));
  return {
    kinetic,
    potential,
    total: kinetic + potential,
    height: length * (1 - Math.cos(state.theta)),
  };
}

export function calculateAngularMomentum(state, parameters) {
  const inertia = parameters.mass * parameters.length ** 2;
  return inertia * state.omega;
}

export function calculateTangentialAcceleration(state, parameters) {
  return parameters.length * state.alpha;
}

export function summarizeState(state, parameters) {
  const energy = calculateEnergy(state, parameters);
  return {
    ...state,
    ...energy,
    angularMomentum: calculateAngularMomentum(state, parameters),
    tangentialAcceleration: calculateTangentialAcceleration(state, parameters),
  };
}
