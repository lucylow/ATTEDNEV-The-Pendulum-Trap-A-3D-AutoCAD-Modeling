import { estimateSmallAnglePeriod } from './pendulum.js';

/** Derived diagnostics for the idealized damped pendulum. */
export function calculateDiagnostics(samples, parameters) {
  const naturalFrequency = Math.sqrt(parameters.gravity / parameters.length);
  const dampingRatio = parameters.damping / (2 * naturalFrequency);
  const criticalDamping = 2 * naturalFrequency;
  const theoreticalPeriod = estimateSmallAnglePeriod(parameters.length, parameters.gravity);
  const finiteSamples = samples.filter((sample) => Number.isFinite(sample.theta) && Number.isFinite(sample.total));
  const energies = finiteSamples.map((sample) => sample.total);
  const initialEnergy = energies[0] ?? 0;
  const finalEnergy = energies.at(-1) ?? 0;
  const peakEnergy = energies.length ? Math.max(...energies) : 0;
  const energyLossPercent = peakEnergy > 1e-12 ? Math.max(0, (peakEnergy - finalEnergy) / peakEnergy * 100) : 0;
  const energyChangePercent = Math.abs(initialEnergy) > 1e-12 ? (finalEnergy - initialEnergy) / Math.abs(initialEnergy) * 100 : null;

  // Estimate period using positive-going zero crossings; two successive crossings span one cycle.
  const crossings = [];
  for (let index = 1; index < finiteSamples.length; index += 1) {
    const previous = finiteSamples[index - 1];
    const current = finiteSamples[index];
    if (previous.theta <= 0 && current.theta > 0 && current.time > previous.time) {
      const fraction = -previous.theta / (current.theta - previous.theta);
      crossings.push(previous.time + fraction * (current.time - previous.time));
    }
  }
  const periods = [];
  for (let index = 1; index < crossings.length; index += 1) periods.push(crossings[index] - crossings[index - 1]);
  const measuredPeriod = periods.length ? periods.reduce((sum, value) => sum + value, 0) / periods.length : null;
  const rmsAngle = finiteSamples.length
    ? Math.sqrt(finiteSamples.reduce((sum, sample) => sum + sample.angleDeg ** 2, 0) / finiteSamples.length)
    : 0;

  return {
    naturalFrequency,
    dampingRatio,
    criticalDamping,
    theoreticalPeriod,
    measuredPeriod,
    cycleCount: periods.length,
    energyLossPercent,
    energyChangePercent,
    initialEnergy,
    finalEnergy,
    rmsAngle,
    sampleCount: finiteSamples.length,
  };
}

export function calculateSmallAngleError(angleDeg) {
  const angle = Math.abs(angleDeg) * Math.PI / 180;
  if (angle < 1e-12) return 0;
  // Relative error of sin(theta) ≈ theta as an acceleration approximation.
  return Math.abs(angle - Math.sin(angle)) / angle * 100;
}

export function calculatePeriodSweep(lengths, gravity) {
  return lengths.map((length) => ({ length, period: estimateSmallAnglePeriod(length, gravity) }));
}
