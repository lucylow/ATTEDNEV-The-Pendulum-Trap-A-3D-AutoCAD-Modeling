import { PendulumSolver } from './pendulum.js';

/**
 * Simulate a virtual sinusoidal excitation over a frequency range and estimate
 * steady-state half peak-to-peak angular response. Results are educational
 * numerical experiments; they are not a hardware design procedure.
 */
export function runFrequencySweep(parameters, options = {}) {
  const startHz = options.startHz ?? 0.1;
  const endHz = options.endHz ?? 1.0;
  const points = options.points ?? 24;
  const dt = options.dt ?? 1 / 180;
  const duration = options.duration ?? 16;
  const windowSeconds = options.windowSeconds ?? 4;
  if (!(parameters.driveAmplitude > 0)) throw new RangeError('Set drive amplitude above zero before running a frequency sweep');
  if (!(Number.isFinite(startHz) && Number.isFinite(endHz) && Number.isInteger(points) && Number.isFinite(dt) && Number.isFinite(duration) && Number.isFinite(windowSeconds) && startHz > 0 && endHz > startHz && points >= 3 && dt > 0 && windowSeconds > 0 && duration > windowSeconds)) {
    throw new RangeError('Invalid frequency sweep settings');
  }
  const results = [];
  for (let index = 0; index < points; index += 1) {
    const frequencyHz = startHz + (endHz - startHz) * index / (points - 1);
    const solver = new PendulumSolver({ ...parameters, initialAngleDeg: 0, driveFrequencyHz: frequencyHz });
    let minAngle = Infinity;
    let maxAngle = -Infinity;
    const totalSteps = Math.ceil(duration / dt);
    const windowStart = duration - windowSeconds;
    for (let step = 0; step < totalSteps; step += 1) {
      const state = solver.step(dt);
      if (state.time >= windowStart) {
        minAngle = Math.min(minAngle, state.angleDeg);
        maxAngle = Math.max(maxAngle, state.angleDeg);
      }
    }
    results.push({ frequencyHz, amplitudeDeg: (maxAngle - minAngle) / 2, minAngleDeg: minAngle, maxAngleDeg: maxAngle });
  }
  const peak = results.reduce((best, item) => item.amplitudeDeg > best.amplitudeDeg ? item : best, results[0]);
  return { results, peak, settings: { startHz, endHz, points, dt, duration, windowSeconds, driveAmplitude: parameters.driveAmplitude } };
}
