export class SampleHistory {
  constructor(limit = 12000) {
    this.limit = limit;
    this.samples = [];
  }
  add(sample) {
    this.samples.push({ ...sample });
    if (this.samples.length > this.limit) this.samples.splice(0, this.samples.length - this.limit);
  }
  clear() { this.samples.length = 0; }
  get length() { return this.samples.length; }
  latest() { return this.samples.at(-1) ?? null; }
  toArray() { return this.samples.map((sample) => ({ ...sample })); }
  decimated(maxPoints = 700) {
    if (this.samples.length <= maxPoints) return this.toArray();
    const stride = Math.ceil(this.samples.length / maxPoints);
    return this.samples.filter((_, index) => index % stride === 0 || index === this.samples.length - 1);
  }
}
