/** Derive idealized sensor channels from simulated state (no physical sensors). */
export function deriveVirtualSensors(sample, parameters) {
  const radialAcceleration = parameters.length * sample.omega ** 2;
  const tangentialAcceleration = parameters.length * sample.alpha;
  return {
    angleSensorDeg: sample.angleDeg,
    rateGyroRadPerSec: sample.omega,
    tangentialAccelerationMps2: tangentialAcceleration,
    radialAccelerationMps2: radialAcceleration,
    resultantAccelerationMps2: Math.hypot(radialAcceleration, tangentialAcceleration),
    bobSpeedMps: sample.speed,
    driveAngularAccelerationRadS2: sample.driveAlpha ?? 0,
    driveTangentialAccelerationMps2: parameters.length * (sample.driveAlpha ?? 0),
  };
}
