import { PendulumSolver } from './pendulum.js';

/** Compare step sizes against a finer numerical reference at a common final time. */
export function runConvergenceStudy(parameters, options = {}) {
  const stepSizes = options.stepSizes ?? [1 / 30, 1 / 60, 1 / 120, 1 / 240, 1 / 480];
  const duration = options.duration ?? 8;
  if (!Array.isArray(stepSizes) || stepSizes.length < 2 || stepSizes.some((dt) => !Number.isFinite(dt) || dt <= 0)) {
    throw new RangeError('At least two positive finite step sizes are required');
  }
  const finest = Math.min(...stepSizes);
  const stepsAtFinest = Math.round(duration / finest);
  const commonDuration = stepsAtFinest * finest;
  for (const dt of stepSizes) {
    const alignedSteps = Math.round(commonDuration / dt);
    if (Math.abs(alignedSteps * dt - commonDuration) > 1e-9) {
      throw new RangeError('Step sizes must divide the common final time consistently');
    }
  }
  const run = (dt) => {
    const solver = new PendulumSolver(parameters);
    const count = Math.round(commonDuration / dt);
    for (let i = 0; i < count; i += 1) solver.step(dt);
    return solver.snapshot();
  };
  const reference = run(finest);
  return [...stepSizes].sort((a, b) => b - a).map((dt) => {
    const result = run(dt);
    return {
      dt,
      steps: Math.round(commonDuration / dt),
      finalTime: result.time,
      angleErrorDeg: Math.abs(result.theta - reference.theta) * 180 / Math.PI,
      omegaErrorRadS: Math.abs(result.omega - reference.omega),
      reference: dt === finest,
    };
  });
}
