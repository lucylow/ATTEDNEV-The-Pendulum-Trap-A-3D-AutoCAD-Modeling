import { APP_CONFIG, TRIGGER_DEFAULTS } from './config.js';
import { PendulumSolver } from './physics/pendulum.js';
import { summarizeState } from './physics/energy.js';
import { deriveVirtualSensors } from './physics/sensors.js';
import { calculateDiagnostics } from './physics/analysis.js';
import { TriggerEngine } from './physics/triggers.js';
import { SampleHistory } from './physics/history.js';
import { runConvergenceStudy } from './physics/convergence.js';
import { runFrequencySweep } from './physics/sweeps.js';
import { ResponseChart } from './ui/chart.js';
import { Dashboard } from './ui/dashboard.js';
import { ParameterControls } from './ui/controls.js';
import { StudyPanels } from './ui/studies.js';
import { downloadText, toCSV } from './utils/download.js';
import { buildCadRows, normalizeAngles } from './utils/cad.js';
import { autoLispFilename, generateAutoLisp } from './utils/autolisp.js';

export class PendulumLabApp {
  constructor(options = {}) {
    this.parameters = { ...APP_CONFIG.defaults };
    this.solver = new PendulumSolver(this.parameters);
    this.triggerEngine = new TriggerEngine(TRIGGER_DEFAULTS, { debounceSeconds: APP_CONFIG.triggerDebounceSeconds });
    this.history = new SampleHistory(APP_CONFIG.historyLimit);
    this.events = [];
    this.running = false;
    this.timeScale = this.parameters.timeScale;
    this.integrationStep = APP_CONFIG.integrationStep;
    this.accumulator = 0;
    this.lastFrameTime = 0;
    this.sampleClock = 0;
    this.lastUiUpdate = 0;
    this.chartMode = 'angle';

    if (!options.scene) throw new Error('A visualization renderer must be supplied at startup');
    this.scene = options.scene;
    this.chart = new ResponseChart(document.getElementById('response-chart'), document.getElementById('chart-empty'));
    this.dashboard = new Dashboard();
    this.studies = new StudyPanels();
    this.controls = new ParameterControls(
      (patch, resetState) => this.updateParameters(patch, resetState),
      (value) => { this.timeScale = value; },
    );

    this.bindUI();
    this.reset();
    this.frame = this.frame.bind(this);
    requestAnimationFrame(this.frame);
  }

  bindUI() {
    this.dashboard.el.runButton.addEventListener('click', () => this.toggleRun());
    document.getElementById('reset-button').addEventListener('click', () => this.reset());
    document.getElementById('defaults-button').addEventListener('click', () => {
      this.integrationStep = APP_CONFIG.integrationStep;
      document.getElementById('step-size-select').value = String(APP_CONFIG.integrationStep);
      document.getElementById('integrator-label').textContent = `${document.getElementById('integrator-select').selectedOptions[0].text} / ${(1 / this.integrationStep).toFixed(0)} Hz`;
      this.reset();
    });
    document.getElementById('single-step').addEventListener('click', () => this.singleStep());
    document.getElementById('view-home').addEventListener('click', () => this.scene.homeCamera());
    document.getElementById('toggle-grid').addEventListener('click', () => this.scene.toggleGrid());
    document.getElementById('toggle-vectors').addEventListener('click', () => this.scene.toggleVectors());
    document.getElementById('clear-log').addEventListener('click', () => {
      this.events = [];
      this.dashboard.renderEvents(this.events);
    });
    document.getElementById('export-csv').addEventListener('click', () => this.exportCSV());
    document.getElementById('export-cad-geometry').addEventListener('click', () => this.exportCadGeometry());
    document.getElementById('export-cad-positions').addEventListener('click', () => this.exportCadPositions());
    document.getElementById('generate-autolisp').addEventListener('click', () => this.generateAutoLispScript());
    document.getElementById('download-autolisp').addEventListener('click', () => this.downloadAutoLisp());
    document.getElementById('copy-autolisp').addEventListener('click', () => this.copyAutoLisp());
    document.getElementById('integrator-select').addEventListener('change', (event) => {
      this.parameters.integrator = event.target.value;
      this.solver.setIntegrator(event.target.value);
      this.reset();
      document.getElementById('integrator-label').textContent = `${event.target.options[event.target.selectedIndex].text} / ${(1 / this.integrationStep).toFixed(0)} Hz`;
    });
    document.getElementById('export-json').addEventListener('click', () => this.exportJSON());
    document.getElementById('step-size-select').addEventListener('change', (event) => {
      this.integrationStep = Number(event.target.value);
      document.getElementById('integrator-label').textContent = `${document.getElementById('integrator-select').selectedOptions[0].text} / ${(1 / this.integrationStep).toFixed(0)} Hz`;
      this.reset();
    });
    document.getElementById('run-convergence').addEventListener('click', () => this.runConvergence());
    document.getElementById('run-frequency-sweep').addEventListener('click', () => this.runSweep());

    document.querySelectorAll('[data-chart]').forEach((button) => button.addEventListener('click', () => {
      document.querySelectorAll('[data-chart]').forEach((item) => item.classList.toggle('active', item === button));
      this.chartMode = button.dataset.chart;
      this.chart.setMode(this.chartMode);
    }));

    this.dashboard.el.triggerList.addEventListener('change', (event) => {
      const enabledId = event.target.dataset.triggerEnabled;
      const thresholdId = event.target.dataset.triggerThreshold;
      if (enabledId) {
        const trigger = this.triggerEngine.definitions.find((item) => item.id === enabledId);
        if (trigger) this.triggerEngine.configure(enabledId, { enabled: event.target.checked });
        this.dashboard.renderTriggers(this.triggerEngine.definitions);
      }
      if (thresholdId) {
        const value = Number(event.target.value);
        if (!Number.isFinite(value) || value < 0) {
          event.target.value = this.triggerEngine.definitions.find((item) => item.id === thresholdId)?.threshold ?? 0;
          return;
        }
        this.triggerEngine.configure(thresholdId, { threshold: value, fired: false });
        this.dashboard.renderTriggers(this.triggerEngine.definitions);
      }
    });

    document.addEventListener('keydown', (event) => {
      const target = event.target;
      const editing = target instanceof HTMLInputElement || target instanceof HTMLSelectElement || target instanceof HTMLTextAreaElement;
      if (event.code === 'Space' && !editing) {
        event.preventDefault();
        this.toggleRun();
      }
    });
  }

  updateParameters(patch, resetState = false) {
    this.parameters = { ...this.parameters, ...patch };
    this.solver.setParameters(this.parameters);
    if (patch.integrator) this.solver.setIntegrator(patch.integrator);
    if (resetState) {
      this.solver.reset(this.parameters.initialAngleDeg);
      this.clearRunData();
    }
    this.refreshCurrentSample();
    if (resetState) this.recordSample(true);
  }

  refreshCurrentSample() {
    const state = this.solver.snapshot();
    const enriched = summarizeState(state, this.parameters);
    const sensors = deriveVirtualSensors(state, this.parameters);
    this.currentSample = { ...enriched, ...sensors };
    this.scene.update(state, this.parameters.length);
    this.dashboard.updateMetrics(this.currentSample, this.parameters);
    this.dashboard.renderTriggers(this.triggerEngine.definitions);
  }

  clearRunData() {
    this.history.clear();
    this.events = [];
    this.triggerEngine.reset();
    this.sampleClock = 0;
    this.dashboard.renderEvents(this.events);
    this.chart.setSamples([]);
    this.dashboard.updateSampleCount(0);
    this.scene.clearTrail();
    this.lastSweep = null;
    this.lastConvergence = null;
    this.studies.reset();
  }

  reset() {
    this.pause();
    this.solver.reset(this.parameters.initialAngleDeg);
    this.clearRunData();
    this.refreshCurrentSample();
    this.recordSample(true);
  }

  toggleRun() {
    if (this.running) this.pause(); else this.run();
  }

  run() {
    this.running = true;
    this.lastFrameTime = 0;
    this.controls.setLocked(true);
    this.dashboard.setRunning(true);
  }

  pause() {
    this.running = false;
    this.accumulator = 0;
    this.controls.setLocked(false);
    this.dashboard.setRunning(false);
  }

  singleStep() {
    if (this.running) this.pause();
    this.integrate(this.integrationStep);
    this.recordSample(true);
    this.refreshCurrentSample();
    this.updateVisuals(performance.now());
  }

  integrate(dt) {
    const state = this.solver.step(dt);
    const enriched = summarizeState(state, this.parameters);
    const sensors = deriveVirtualSensors(state, this.parameters);
    this.currentSample = { ...enriched, ...sensors };
    const newlyFired = this.triggerEngine.evaluate(this.currentSample);
    if (newlyFired.length) {
      this.events.push(...newlyFired);
      if (this.events.length > 300) this.events.splice(0, this.events.length - 300);
      this.dashboard.renderEvents(this.events);
      this.dashboard.renderTriggers(this.triggerEngine.definitions);
    }
    if (this.solver.time - this.sampleClock >= this.parameters.sampleInterval - 1e-6) {
      this.recordSample(false);
    }
  }

  recordSample(force = false) {
    const latest = this.history.latest();
    if (latest && Math.abs(latest.time - this.solver.time) < 1e-10) return;
    if (!force && this.solver.time - this.sampleClock < this.parameters.sampleInterval - 1e-6) return;
    const state = this.solver.snapshot();
    const enriched = summarizeState(state, this.parameters);
    const sensors = deriveVirtualSensors(state, this.parameters);
    this.history.add({ ...enriched, ...sensors });
    this.sampleClock = this.solver.time;
    this.dashboard.updateSampleCount(this.history.length);
    this.updateDiagnostics();
  }

  updateVisuals(timestamp) {
    this.scene.update(this.solver.snapshot(), this.parameters.length);
    if (timestamp - this.lastUiUpdate > 90) {
      this.dashboard.updateMetrics(this.currentSample, this.parameters);
      this.dashboard.updateRangeLabel(this.solver.time);
      this.chart.setSamples(this.history.decimated(800));
      this.updateDiagnostics();
      this.lastUiUpdate = timestamp;
    }
    this.scene.render();
  }

  frame(timestamp) {
    if (this.running) {
      if (!this.lastFrameTime) this.lastFrameTime = timestamp;
      const frameDelta = Math.min((timestamp - this.lastFrameTime) / 1000, APP_CONFIG.maxFrameDelta);
      this.lastFrameTime = timestamp;
      this.accumulator += frameDelta * this.timeScale;
      let substeps = 0;
      while (this.accumulator >= this.integrationStep && substeps < APP_CONFIG.maxSubstepsPerFrame) {
        this.integrate(this.integrationStep);
        this.accumulator -= this.integrationStep;
        substeps += 1;
      }
      if (substeps === APP_CONFIG.maxSubstepsPerFrame) this.accumulator = Math.min(this.accumulator, this.integrationStep);
    }
    this.updateVisuals(timestamp);
    requestAnimationFrame(this.frame);
  }

  updateDiagnostics() {
    const result = calculateDiagnostics(this.history.samples, this.parameters);
    document.getElementById('diag-frequency').innerHTML = `${result.naturalFrequency.toFixed(3)} <small>rad/s</small>`;
    document.getElementById('diag-period').innerHTML = `${result.theoreticalPeriod.toFixed(3)} <small>s</small>`;
    document.getElementById('diag-damping').textContent = result.dampingRatio.toFixed(4);
    document.getElementById('diag-observed').innerHTML = result.measuredPeriod === null ? '— <small>s</small>' : `${result.measuredPeriod.toFixed(3)} <small>s</small>`;
    const energyChange = result.energyChangePercent;
    document.getElementById('diag-energy-loss').innerHTML = energyChange === null ? '— <small>%</small>' : `${energyChange >= 0 ? '+' : ''}${energyChange.toFixed(1)} <small>%</small>`;
    document.getElementById('diag-rms').innerHTML = `${result.rmsAngle.toFixed(2)} <small>°</small>`;
  }

  exportRows() {
    return this.history.toArray().map((sample) => ({
      time_s: sample.time,
      angle_rad: sample.theta,
      angle_deg: sample.angleDeg,
      angular_velocity_rad_s: sample.omega,
      angular_acceleration_rad_s2: sample.alpha,
      tangential_speed_m_s: sample.speed,
      kinetic_energy_J: sample.kinetic,
      potential_energy_J: sample.potential,
      total_energy_J: sample.total,
      angular_momentum_kg_m2_s: sample.angularMomentum,
      virtual_radial_acceleration_m_s2: sample.radialAccelerationMps2,
      virtual_tangential_acceleration_m_s2: sample.tangentialAccelerationMps2,
      virtual_resultant_acceleration_m_s2: sample.resultantAccelerationMps2,
      virtual_drive_angular_acceleration_rad_s2: sample.driveAngularAccelerationRadS2,
      virtual_drive_tangential_acceleration_m_s2: sample.driveTangentialAccelerationMps2,
      virtual_angle_sensor_deg: sample.angleSensorDeg,
      virtual_rate_gyro_rad_s: sample.rateGyroRadPerSec,
    }));
  }

  exportCSV() {
    const rows = this.exportRows();
    if (!rows.length) return;
    downloadText('pendulum-experiment.csv', toCSV(rows), 'text/csv;charset=utf-8');
  }

  exportCadGeometry() {
    const rows = buildCadRows(this.parameters, [this.parameters.initialAngleDeg]);
    downloadText('pendulum-autocad-geometry.csv', toCSV(rows), 'text/csv;charset=utf-8');
  }

  exportCadPositions() {
    const input = document.getElementById('cad-angle-list');
    const angles = normalizeAngles(input.value);
    if (!angles.length) {
      input.focus();
      input.setCustomValidity('Enter one or more angles from -80 to 80 degrees.');
      input.reportValidity();
      return;
    }
    input.setCustomValidity('');
    downloadText('pendulum-autocad-positions.csv', toCSV(buildCadRows(this.parameters, angles)), 'text/csv;charset=utf-8');
  }

  autoLispAngles() {
    const input = document.getElementById('cad-angle-list');
    const angles = normalizeAngles(input.value);
    return angles.length ? angles : [this.parameters.initialAngleDeg];
  }

  generateAutoLispScript() {
    const script = generateAutoLisp(this.parameters, this.autoLispAngles());
    document.getElementById('autolisp-preview').value = script;
    document.getElementById('autolisp-status').textContent = `${script.split('\n').length} lines generated`;
    return script;
  }

  downloadAutoLisp() {
    const script = document.getElementById('autolisp-preview').value || this.generateAutoLispScript();
    downloadText(autoLispFilename(this.parameters), script, 'text/plain;charset=utf-8');
  }

  async copyAutoLisp() {
    const script = document.getElementById('autolisp-preview').value || this.generateAutoLispScript();
    const button = document.getElementById('copy-autolisp');
    try {
      await navigator.clipboard.writeText(script);
      button.textContent = 'Copied';
      setTimeout(() => { button.textContent = 'Copy script'; }, 1400);
    } catch {
      document.getElementById('autolisp-preview').select();
      button.textContent = 'Select to copy';
      setTimeout(() => { button.textContent = 'Copy script'; }, 1400);
    }
  }

  runConvergence() {
    const button = document.getElementById('run-convergence');
    button.disabled = true;
    button.textContent = 'Calculating…';
    try {
      const rows = runConvergenceStudy(this.parameters, { duration: 8 });
      this.studies.renderConvergence(rows);
      this.lastConvergence = rows;
    } catch (error) {
      document.getElementById('convergence-table').textContent = error.message;
    } finally {
      button.disabled = false;
      button.textContent = 'Run convergence check';
    }
  }

  runSweep() {
    const button = document.getElementById('run-frequency-sweep');
    button.disabled = true;
    button.textContent = 'Calculating…';
    try {
      const report = runFrequencySweep(this.parameters);
      this.studies.renderFrequencySweep(report);
      this.lastSweep = report;
    } catch (error) {
      document.getElementById('frequency-summary').textContent = error.message;
    } finally {
      button.disabled = false;
      button.textContent = 'Run frequency sweep';
    }
  }

  exportJSON() {
    const payload = {
      title: APP_CONFIG.title,
      version: APP_CONFIG.version,
      exportedAt: new Date().toISOString(),
      scope: 'simulation-only; all event triggers remain inside the browser application',
      model: 'ideal rigid massless rod with point-mass bob, linear viscous angular damping, and optional sinusoidal virtual excitation',
      parameters: this.parameters,
      samples: this.exportRows(),
      events: this.events,
      integrationStep_s: this.integrationStep,
      frequencySweep: this.lastSweep ?? null,
      convergenceStudy: this.lastConvergence ?? null,
      triggers: this.triggerEngine.definitions.map(({ id, name, enabled, kind, threshold, direction, repeat, fired }) => ({ id, name, enabled, kind, threshold, direction, repeat, fired })),
    };
    downloadText('pendulum-experiment.json', JSON.stringify(payload, null, 2), 'application/json;charset=utf-8');
  }
}
