# 12 — Frequency-response study

The frequency sweep runs independent simulations. For each sample frequency, it sets initial angle and angular rate to zero, applies the configured drive amplitude, and integrates for a fixed duration. The default settings are 24 evenly spaced frequencies from 0.1 to 1.0 Hz, a 1/180 s step, 16 s total duration, and a final 4 s measurement window.

The response metric is

`amplitude_estimate = (max(angle_deg) - min(angle_deg)) / 2`

computed within the final window. It is a sampled peak-to-peak estimate, not a fitted frequency response function. The displayed peak is simply the largest response among the tested frequencies. A longer settling duration or denser frequency grid may be needed for high-Q systems or very narrow response peaks.

The sweep is a numerical experiment inside the page. It does not prescribe a physical forcing mechanism.
