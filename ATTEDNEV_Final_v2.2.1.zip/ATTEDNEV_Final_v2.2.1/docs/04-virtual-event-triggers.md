# 04 — Virtual event triggers

The trigger monitor evaluates simulated state and appends local UI log records. It does not connect to devices or emit commands beyond the web page.

## Trigger channels

1. Absolute angular displacement (`angle`, above/below threshold).
2. Absolute angular velocity (`omega`, above/below threshold).
3. Total mechanical energy (`energy`, above/below threshold).
4. Elapsed simulation time (`time`, above/below threshold).
5. Equilibrium crossing (`zero-crossing`, sign change in angle).
6. Turning point (`turning-point`, sign change in angular velocity).

## Evaluation behavior

Triggers are evaluated on every integration step, not just on chart sample intervals. Threshold events can be one-shot or repeat with a minimum debounce interval. Crossing and turning-point events compare the current state with the previous integration sample. They are repeat-enabled by default only where configured in the trigger definitions.

## Event record

An event stores its ID, label, type, simulation time, measured value, optional threshold, and display message. Events are included in JSON exports. They are not safety interlocks, physical sensors, actuators, or real-world trigger instructions.
