# 10 — Limitations and extension points

## Current limitations

- The model is planar and has one angular degree of freedom.
- The bob is a point mass; body dimensions and distributed inertia are ignored.
- The rod is rigid and massless; the support is illustrative only.
- Damping is linear in angular velocity; pivot friction and aerodynamic drag are not separated.
- The sinusoidal excitation is a prescribed angular-acceleration input, not a modeled physical actuator or applied-force geometry.
- No collisions, stops, impact losses, cable elasticity, rod flexibility, or moving support are modeled.
- Virtual sensor channels are ideal and noise-free.
- There is no adaptive time-step or local truncation-error estimate.
- The frequency sweep samples a finite list of frequencies and a finite observation window; the highest sampled response is not a continuous optimization.
- Three.js is loaded from a CDN and therefore requires network access for the 3D renderer. A 2D canvas fallback is included.

## Appropriate educational extensions

Useful safe extensions include sensor noise and bias models, parameter uncertainty, a double or compound pendulum, solver error estimators, confidence intervals, additional chart channels, and comparison with a classroom laboratory dataset. Keep event-trigger actions local to the software simulation.
