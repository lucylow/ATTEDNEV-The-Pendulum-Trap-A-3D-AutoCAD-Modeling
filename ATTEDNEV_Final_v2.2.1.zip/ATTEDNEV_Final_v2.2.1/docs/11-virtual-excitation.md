# 11 — Virtual sinusoidal excitation

The model adds a prescribed angular-acceleration excitation term:

`alpha_drive(t) = A sin(2 pi f t + phi)`

The full equation is

`theta_ddot = -(g/L) sin(theta) - c theta_dot + alpha_drive(t)`

The amplitude `A` is measured in rad/s², frequency `f` in Hz, and phase `phi` in radians in the solver. The interface stores phase in degrees, currently defaulted to zero. Setting amplitude to zero disables excitation regardless of the selected frequency.

This is a deliberately abstract input. It bypasses any actuator, force application point, torque transmission, or hardware. This makes the mathematical behavior clear and keeps the project strictly simulation-only.

When excitation is active, mechanical energy can increase or decrease depending on the instantaneous phase relation between drive and motion. A fixed energy-conservation expectation is therefore not appropriate.
