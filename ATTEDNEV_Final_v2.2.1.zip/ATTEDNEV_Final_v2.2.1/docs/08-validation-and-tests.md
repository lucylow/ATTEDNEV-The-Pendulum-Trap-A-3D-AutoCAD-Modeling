# 08 — Validation and tests

Run `npm test` from the project root. The current suite contains 12 tests:

1. Small-angle period matches the analytical expression.
2. Non-positive period inputs are rejected.
3. Undamped RK4 conserves mechanical energy closely over a 12-second run.
4. Semi-implicit Euler, explicit Euler, and split damped Verlet advance a finite state.
5. Positive viscous damping reduces energy in the unforced model.
6. Sinusoidal virtual excitation changes the response from the unforced rest state.
7. Invalid parameters, invalid integration steps, and unknown solver names are rejected.
8. A threshold event fires once and resets correctly.
9. Equilibrium-crossing and turning-point events detect sign transitions.
10. Diagnostic outputs remain finite for the test case and expose energy change.
11. RK4 final-state error decreases as the step is refined against the 480 Hz reference.
12. A frequency sweep returns finite response values and rejects zero drive amplitude.

These are regression tests of selected mathematical properties and software paths. They do not constitute experimental correlation, exhaustive numerical verification, safety certification, or structural engineering approval.

## Recommended manual browser QA

- Try every preset and confirm each resets the history.
- Compare 120 Hz and 480 Hz with the same method and initial parameters.
- Use the driven preset, run the frequency sweep, and confirm its peak marker is drawn.
- Disable each trigger and check that subsequent matching events are not logged.
- Test mobile widths, keyboard focus, browser zoom, and no-WebGL fallback.
- Export CSV and JSON, open them in a text editor, and confirm the active parameters are included.
