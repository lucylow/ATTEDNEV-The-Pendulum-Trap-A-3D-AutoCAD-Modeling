# 09 — Application architecture

- `config.js`: defaults, presets, solver cadence, and trigger definitions.
- `physics/pendulum.js`: nonlinear free/driven state equation and four integrators.
- `physics/energy.js`: energy, angular momentum, and state enrichment.
- `physics/sensors.js`: derived virtual sensor channels.
- `physics/triggers.js`: threshold and sign-transition event monitor.
- `physics/history.js`: bounded sampled-state storage and decimation.
- `physics/analysis.js`: natural frequency, damping ratio, observed period, energy change, and RMS angle.
- `physics/convergence.js`: common-duration integration-step error comparison.
- `physics/sweeps.js`: repeated forced simulations across a drive-frequency range.
- `visual/scene.js`: Three.js renderer, camera, generic support reference, pendulum, trail, and vector.
- `visual/fallback.js`: 2D canvas schematic for unavailable WebGL contexts.
- `ui/controls.js`: parameter controls, presets, sample-rate control, and run locking.
- `ui/chart.js`: Canvas-based live time-series chart.
- `ui/dashboard.js`: metrics, event records, and trigger controls.
- `ui/studies.js`: frequency-response drawing and study tables.
- `utils/`: formatting and data download helpers.
- `app.js`: lifecycle, fixed-step clock, trigger evaluation, history, and exports.

Physics modules do not depend on DOM elements or Three.js. Node tests import the physics layer directly, without a browser rendering context.
