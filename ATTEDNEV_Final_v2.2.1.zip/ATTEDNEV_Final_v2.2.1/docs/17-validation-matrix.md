# 17 — Validation matrix

| Area | Automated verification | Browser/manual verification still needed |
|---|---|---|
| Core equation | Free, damped, driven unit tests | Compare selected cases with a lab dataset or trusted reference solver |
| Integrators | Finite stepping; RK4 convergence check | Visual comparison of solver drift at several rates |
| Virtual events | Threshold and sign-transition tests | Verify status labels and log rendering in a live page |
| Frequency sweep | Finite sampled responses and zero-drive guard | Inspect peak shape and increase frequency resolution as needed |
| UI wiring | Static ID audit | Click through every control in desktop and mobile browsers |
| Exports | Source-level payload construction | Download and open CSV/JSON from a browser |
| Renderer | JavaScript syntax and dynamic fallback architecture | Verify WebGL on a supported GPU and 2D fallback without WebGL |

The build was checked with Node's syntax parser, the bundled Node test suite, and a static HTML element-ID audit. A full interactive browser session could not be completed in the build environment; the Manus publish instructions include a specific browser QA checklist.
