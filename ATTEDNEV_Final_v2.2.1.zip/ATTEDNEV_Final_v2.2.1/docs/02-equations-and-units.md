# 02 — Equations and units

## Equation of motion

`theta_ddot + c theta_dot + (g/L) sin(theta) = A sin(2 pi f t + phi)`

Set `A = 0` for the free damped pendulum. This is the full nonlinear equation; the solver does not replace `sin(theta)` with `theta`.

| Symbol | Meaning | Unit |
|---|---|---|
| `theta` | Angular displacement | rad |
| `omega` | Angular velocity | rad/s |
| `alpha` | Angular acceleration | rad/s² |
| `L` | Pivot-to-bob distance | m |
| `m` | Bob mass | kg |
| `g` | Gravitational field strength | m/s² |
| `c` | Linear angular damping coefficient | s⁻¹ |
| `A` | Virtual drive angular-acceleration amplitude | rad/s² |
| `f` | Virtual drive frequency | Hz |
| `phi` | Virtual drive phase | rad (stored UI parameter in degrees) |

The bob mass cancels from the ideal equation of motion because gravitational torque and point-mass rotational inertia are both proportional to mass. Mass remains in the energy and angular-momentum outputs.

## Energy

`T = 1/2 m (L omega)^2`

`V = m g L (1 - cos(theta))`

`E = T + V`

The potential-energy reference is the lowest point. With no damping and no drive, energy should be nearly conserved by a sufficiently resolved numerical solution. Damping removes energy; the drive can add or remove energy depending on phase. Consequently, an energy-change diagnostic is signed and is not labelled as guaranteed energy loss.

## Small-angle reference

When `|theta|` is small, `sin(theta) ≈ theta`. For the undamped, unforced model, `omega_n = sqrt(g/L)` and `T = 2 pi sqrt(L/g)`. These are reference values, not exact large-angle periods or driven-response frequencies.
