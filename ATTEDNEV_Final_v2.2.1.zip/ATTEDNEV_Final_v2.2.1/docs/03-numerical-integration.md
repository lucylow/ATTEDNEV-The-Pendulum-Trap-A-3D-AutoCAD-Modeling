# 03 — Numerical integration

The default solver uses a fixed integration step of 1/120 s. The browser animation clock is separate from the physics clock, so rendering rate does not define the integration cadence. Available rates are 30, 60, 120, 240, and 480 Hz.

## Integrators

- **RK4:** classical fourth-order Runge–Kutta for the coupled angle/rate state. The sinusoidal drive is evaluated at the appropriate intermediate stage times.
- **Semi-implicit Euler:** updates angular rate before angle. It is a simple comparison method for mechanical systems.
- **Explicit Euler:** evaluates both derivatives from the start-of-step state. It is included for method comparison, not as the preferred method.
- **Split damped velocity Verlet:** applies exact half-step exponential decay for linear damping around a conservative kick-drift-kick update. The drive is evaluated at the interval endpoints. It is a symmetric split approximation for this equation, not a general-purpose solver for every dissipative system.

## Fixed-step clock

Playback speed changes how many fixed steps are processed per display frame; it does not change the step size. The frame accumulator and substep budget prevent an excessive catch-up burst after a delayed browser frame. If the budget is reached, the accumulator is capped, so simulation time can diverge from wall-clock time during sustained rendering overload.

## Comparison guidance

The convergence panel runs a common-duration comparison against a finer 480 Hz reference. A smaller difference is evidence that the selected result is closer to the numerical reference for that setup, but the reference itself may still have error. Compare multiple solvers and reduce step size before drawing conclusions.
