# 14 — Virtual sensor model

All sensor-like channels are calculated directly from the numerical state. No device connection exists.

- Angle channel: `theta` converted to degrees.
- Rate channel: `omega` in rad/s.
- Radial acceleration magnitude: `L omega^2`.
- Tangential acceleration: `L alpha`.
- Resultant acceleration magnitude: `hypot(radial, tangential)`.
- Drive acceleration: the instantaneous sinusoidal term.
- Drive tangential contribution: `L alpha_drive`.

The sensor layer currently has no random noise, bias, quantization, delay, saturation, dropout, or sampling jitter. Those could be added as software-only transformations without changing the governing equation.
