# 13 — Numerical convergence study

The convergence study runs the currently selected integrator at 30, 60, 120, 240, and 480 Hz. It compares final angular displacement and angular velocity at a common simulated time, using the finest run as the numerical reference.

The error metrics are absolute final-state differences:

- `angle_error_deg = abs(theta_dt - theta_reference) * 180/pi`
- `rate_error_rad_s = abs(omega_dt - omega_reference)`

The default duration is 8 s. Step sizes are required to divide the common final time consistently. When a run uses a coarse or unstable method, error may not decrease monotonically; that itself is useful information about the selected integration method and step size.

The finest numerical run is not an exact solution. For stronger validation, compare to a high-precision external solver or analytical small-angle results in a regime where those assumptions are valid.
