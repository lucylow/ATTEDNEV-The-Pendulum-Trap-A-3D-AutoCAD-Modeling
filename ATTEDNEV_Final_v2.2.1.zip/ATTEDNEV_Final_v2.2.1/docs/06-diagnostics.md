# 06 — Diagnostics

- **Natural frequency:** `sqrt(g/L)` for the unforced, undamped, small-angle linearization.
- **Small-angle theoretical period:** `2 pi sqrt(L/g)`.
- **Damping ratio:** `c / (2 sqrt(g/L))` for the normalized small-angle unforced equation.
- **Observed period:** mean time between consecutive positive-going zero crossings in the recorded sampled response. It requires sufficient periodic data and can be unreliable for strongly driven or transient signals.
- **Energy change:** signed percentage difference between the latest and first recorded mechanical energy. The value can be positive when external drive supplies energy. It is undefined when the initial energy is effectively zero.
- **RMS angle:** root-mean-square of the sampled angular displacement in degrees.

The frequency/damping reference values are based on the free small-angle model. They do not fully characterize a strongly nonlinear or driven pendulum. For driven response, use the frequency sweep in addition to these indicators.
