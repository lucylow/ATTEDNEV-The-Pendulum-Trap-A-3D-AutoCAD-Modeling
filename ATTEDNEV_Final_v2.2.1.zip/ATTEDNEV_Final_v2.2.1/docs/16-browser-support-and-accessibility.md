# 16 — Browser support and accessibility

The 3D renderer requires WebGL and a browser that supports ES modules, `ResizeObserver`, and modern JavaScript. It loads Three.js modules from a CDN. If the WebGL renderer cannot initialize, `main.js` selects a 2D Canvas schematic fallback that retains the key visible pendulum position and vector toggle.

The application uses native form controls and labels for the physical parameters. Keyboard Space toggles run/pause unless focus is inside an editable control. Buttons expose visible focus styles. A reduced-motion media query suppresses optional CSS transitions. The response and study plots are canvas drawings with accessible labels; they should be interpreted alongside the numeric diagnostics and exported datasets.

The canvas renderer does not provide the same orbit/zoom interaction as the 3D view. This is a fallback for visualization continuity, not a fully equivalent camera implementation.
