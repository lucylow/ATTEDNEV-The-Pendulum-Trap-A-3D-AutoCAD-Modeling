# 05 — Virtual sensor channels

The software derives sensor-like channels from the idealized model state. These values are computed quantities, not readings from physical instruments.

| Virtual channel | Source | Unit |
|---|---|---|
| Angle | State angle converted to degrees | ° |
| Angular rate | State angular velocity | rad/s |
| Tangential acceleration | `L * alpha` | m/s² |
| Radial acceleration | `L * omega²` | m/s² |
| Bob speed | `L * omega` magnitude | m/s |
| Resultant acceleration | Euclidean combination of radial and tangential components | m/s² |

The current channels are ideal and noise-free. The architecture keeps sensor derivation in a separate module so noise, bias, quantization, and sample delay can be studied as independent extensions without changing the equation of motion.
