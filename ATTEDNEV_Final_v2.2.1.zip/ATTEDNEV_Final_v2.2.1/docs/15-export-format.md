# 15 — Export formats

## CSV

The CSV download contains one row per recorded sample. Columns use descriptive names with SI unit suffixes. It is suitable for spreadsheets and external plotting software. Only sampled history is included, not every internal integration step.

## JSON

The JSON bundle includes:

- project title and version;
- UTC export timestamp;
- simulation-only scope statement;
- model description;
- physical and drive parameters;
- integration step in seconds;
- sampled history records;
- virtual event records;
- trigger definitions and states;
- most recent frequency sweep report, if one was run.

The convergence table is currently displayed in the page but is not separately included in JSON export. The frequency sweep is included when present.
