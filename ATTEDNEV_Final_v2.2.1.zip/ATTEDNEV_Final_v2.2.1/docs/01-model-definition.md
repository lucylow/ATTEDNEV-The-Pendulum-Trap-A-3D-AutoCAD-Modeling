# 01 — Model definition

## Purpose

The simulator is a transparent educational model of a planar, single-degree-of-freedom pendulum. It exposes physical parameters, numerical state, virtual event conditions, sampled response data, and numerical study tools in one browser workspace.

## Coordinate convention

The pivot is fixed in the world frame. The angle `theta` is zero when the bob hangs directly downward. Positive angle moves the bob toward positive world X. The rod lies in the X–Y plane and its length is `L`.

- `x = L sin(theta)`
- `y = -L cos(theta)`
- `omega = d(theta)/dt`
- tangential speed magnitude `v = L |omega|`

## Idealizations

The rod is rigid and massless, and the bob is a point mass. The pivot has no modeled geometric clearance. Dissipation is represented by a linear angular-velocity term. The support is a visualization only and has no structural analysis. No contact, collisions, rod flexibility, cable slack, or air-drag model are included.

## Virtual excitation

An optional sinusoidal angular-acceleration term can be enabled to study driven response. It exists only in the numerical model and is not connected to external hardware or an actuator.

The simulation is appropriate for classroom exploration and software testing, not for certifying or fabricating a real structure.
