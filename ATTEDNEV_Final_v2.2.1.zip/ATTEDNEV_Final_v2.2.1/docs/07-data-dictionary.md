# 07 — Data dictionary

## Recorded sample fields

| Field | Meaning | Unit |
|---|---|---|
| `time` | Simulation time | s |
| `theta` | Angular displacement | rad |
| `angleDeg` | Angular displacement | ° |
| `omega` | Angular velocity | rad/s |
| `alpha` | Angular acceleration | rad/s² |
| `driveAlpha` | Instantaneous virtual excitation term | rad/s² |
| `speed` | Tangential speed magnitude | m/s |
| `kinetic` | Kinetic energy | J |
| `potential` | Gravitational potential energy | J |
| `total` | Total mechanical energy | J |
| `height` | Bob height above the lowest position | m |
| `angularMomentum` | Angular momentum about the pivot | kg·m²/s |
| `radialAccelerationMps2` | Virtual radial acceleration magnitude | m/s² |
| `tangentialAccelerationMps2` | Virtual tangential acceleration | m/s² |
| `resultantAccelerationMps2` | Resultant acceleration magnitude | m/s² |
| `angleSensorDeg` | Ideal derived angle channel | ° |
| `rateGyroRadPerSec` | Ideal derived angular-rate channel | rad/s |
| `driveAngularAccelerationRadS2` | Virtual drive contribution | rad/s² |
| `driveTangentialAccelerationMps2` | Tangential acceleration contribution from drive term | m/s² |

CSV contains sampled rows only. JSON includes model metadata, parameters, integration step, sampled rows, trigger definitions, event log, and the most recent frequency sweep if one was run.
